// category.service.ts

import { Injectable } from '@nestjs/common';
import { PrismaClient, Category } from '@prisma/client';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';

@Injectable()
export class CategoryService {
  constructor(private prisma: PrismaClient) {}

  async createCategory(
    createCategoryDto: CreateCategoryDto,
  ): Promise<Category> {
    const { label, description } = createCategoryDto;
    const name = this.toCamelCase(label);
    return this.prisma.category.create({
      data: {
        name,
        label,
        description,
      },
    });
  }

  async getAllCategories(page: any): Promise<any> {
    if (!page) {
      const categories = await this.prisma.category.findMany();
      return { categories };
    }

    const categories = await this.prisma.category.findMany({
      skip: (page - 1) * 20,
      take: 20,
    });

    const totalPage = Math.ceil((await this.prisma.category.count()) / 20);
    return { categories, totalPage };
  }

  async getCategoryById(id: string): Promise<Category | null> {
    return this.prisma.category.findUnique({ where: { id } });
  }

  async updateCategory(
    id: string,
    updateCategoryDto: UpdateCategoryDto,
  ): Promise<Category> {
    const { label, description } = updateCategoryDto;
    let name;
    if (label) {
      name = this.toCamelCase(label);
    }
    return this.prisma.category.update({
      where: { id },
      data: {
        name,
        label,
        description,
      },
    });
  }

  async deleteCategory(id: string): Promise<Category> {
    return this.prisma.category.delete({ where: { id } });
  }
  toCamelCase(str: string): string {
    str = str.toLowerCase();
    return str
      .replace(/(?:^|[^a-zA-Z])([a-zA-Z])/g, function (_, char) {
        return char.toUpperCase();
      })
      .replace(/\s+|\([^)]*\)/g, '')
      .replace(/\(|\)/g, '')
      .replace(/^([A-Z])/, function (char) {
        return char.toLowerCase();
      });
  }
}
