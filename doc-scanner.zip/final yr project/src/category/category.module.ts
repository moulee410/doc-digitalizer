// category.module.ts

import { Module } from '@nestjs/common';
import { CategoryController } from './category.controller';
import { CategoryService } from './category.service';
import { PrismaClient } from '@prisma/client';

@Module({
  controllers: [CategoryController],
  providers: [
    CategoryService,
    {
      provide: PrismaClient,
      useValue: new PrismaClient(),
    },
  ],
})
export class CategoryModule {}
