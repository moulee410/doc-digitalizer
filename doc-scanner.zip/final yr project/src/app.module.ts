import { MiddlewareConsumer, Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { StartService } from './start.service';
import { UserModule } from './user/user.module';
import { RolesModule } from './roles/roles.module';
import { SpecificTypeController } from './specific_type/specific_type.controller';
import { SpecificTypeService } from './specific_type/specific_type.service';
import { SpecificTypeModule } from './specific_type/specific_type.module';
import { FinderModule } from './finder/finder.module';
import { SubcategoryModule } from './subcategories/subcategory.module';
import { CategoryModule } from './category/category.module';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { AttributeNamesModule } from './attribute-names/attribute-names.module';
import { ProductModule } from './product/product.module';
import { PartsModule } from './parts/parts.module';
import { TasksModule } from './tasks/tasks.module';
import { LoggingMiddleware } from './middlewares/logging.middleware';
import { MiddlewareModule } from './middlewares/middleware.module';
import { ImgModule } from './img/img.module';

@Module({
  imports: [
    UserModule,
    AuthModule,
    RolesModule,
    SpecificTypeModule,
    FinderModule,
    SubcategoryModule,
    CategoryModule,
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, 'downloads'),
      serveRoot: '/downloads',
    }),
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', 'client', 'build'),
    }),
    AttributeNamesModule,
    ProductModule,
    PartsModule,
    TasksModule,
    MiddlewareModule,
    ImgModule,
  ],
  controllers: [AppController, SpecificTypeController],
  providers: [AppService, StartService, SpecificTypeService],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggingMiddleware).forRoutes('*'); // Apply the middleware to all routes
  }
}
