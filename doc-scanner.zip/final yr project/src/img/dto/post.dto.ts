export class ImgPost {
   extractedText:string
}