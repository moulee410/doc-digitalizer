import { Body, Controller, Get, Post } from '@nestjs/common';
import { ImgService } from './img.service';

@Controller('img')
export class ImgController {

    constructor(private readonly imgservice: ImgService) {}

    @Post()
    async createImage(@Body() createImgDto: { extractedText: string }) {
      return this.imgservice.post(createImgDto.extractedText);
    }
    @Get()
    async getimg() {
        return await this.imgservice.get();
    }

}
