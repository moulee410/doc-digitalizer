import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { ImgPost } from './dto/post.dto';

@Injectable()
export class ImgService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  async post(te: any) {
    try {
      return await this.prisma.img.create({
        data: {
          extractedText: te, // Ensure 'te' is the value you want to assign to 'extractedText'
        },
      });
    } catch (error) {
      console.error('Error creating image:', error);
      throw error;
    }
  }
  

  async get() {
    return await this.prisma.img.findMany();
  }
}
