// specific_type.module.ts

import { Module } from '@nestjs/common';
import { SpecificTypeService } from './specific_type.service';
import { SpecificTypeController } from './specific_type.controller';

@Module({
  controllers: [SpecificTypeController],
  providers: [SpecificTypeService],
})
export class SpecificTypeModule {}
