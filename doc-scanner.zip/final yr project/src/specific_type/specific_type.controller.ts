import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  NotFoundException,
  Query,
} from '@nestjs/common';
import { SpecificTypeService } from './specific_type.service';
import { CreateSpecificTypeDto } from './dto/create_specific_type.dto';
import { UpdateSpecificTypeDto } from './dto/update_specific_type.dto';

@Controller('specifictypes')
export class SpecificTypeController {
  constructor(private readonly specificTypeService: SpecificTypeService) {}

  @Get()
  async findAll(@Query('page') page?: any) {
    return this.specificTypeService.findAll(page ? parseInt(page) : undefined);
  }

  @Get('onlywithattributenames')
  async findOnlyWithAttributeNames() {
    return this.specificTypeService.findOnlyWithAttributeNames();
  }
  @Get(':id')
  async findOne(@Param('id') id: string) {
    const specificType = await this.specificTypeService.findOne(id);
    if (!specificType) {
      throw new NotFoundException(`SpecificType with id ${id} not found`);
    }
    return specificType;
  }

  @Post()
  async create(@Body() createSpecificTypeDto: CreateSpecificTypeDto) {
    return this.specificTypeService.create(createSpecificTypeDto);
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateSpecificTypeDto: UpdateSpecificTypeDto,
  ) {
    return this.specificTypeService.update(id, updateSpecificTypeDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.specificTypeService.remove(id);
  }
}
