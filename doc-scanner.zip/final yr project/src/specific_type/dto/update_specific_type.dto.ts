// update_specific_type.dto.ts

export class UpdateSpecificTypeDto {
  label?: string;
  description?: string;
  subCategoryId?: string;
}
