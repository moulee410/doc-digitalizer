// create_specific_type.dto.ts

export class CreateSpecificTypeDto {
  label: string;
  description: string;
  subCategoryId: string;
}
