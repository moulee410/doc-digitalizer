import { Test, TestingModule } from '@nestjs/testing';
import { SpecificTypeController } from './specific_type.controller';

describe('SpecificTypeController', () => {
  let controller: SpecificTypeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SpecificTypeController],
    }).compile();

    controller = module.get<SpecificTypeController>(SpecificTypeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
