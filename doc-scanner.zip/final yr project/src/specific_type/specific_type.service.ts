import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaClient, SpecificType } from '@prisma/client';
import { CreateSpecificTypeDto } from './dto/create_specific_type.dto';
import { UpdateSpecificTypeDto } from './dto/update_specific_type.dto';

const prisma = new PrismaClient();

@Injectable()
export class SpecificTypeService {
  async findAll(page: any): Promise<any> {
    if (!page) {
      const specificTypes = await prisma.specificType.findMany();
      return { specificTypes };
    }
    const specificTypes = await prisma.specificType.findMany({
      skip: (page - 1) * 20,
      take: 20,
    });
    const totalPage = Math.ceil((await prisma.specificType.count()) / 20);

    return { specificTypes, totalPage };
  }

  async findOne(id: string): Promise<SpecificType | null> {
    const specificType = await prisma.specificType.findUnique({
      where: { id },
    });
    if (!specificType) {
      throw new NotFoundException(`SpecificType with id ${id} not found`);
    }
    return specificType;
  }

  async create(data: CreateSpecificTypeDto): Promise<SpecificType> {
    const value = { ...data, name: this.toCamelCase(data.label) };
    return prisma.specificType.create({ data: value });
  }

  async update(id: string, data: any): Promise<SpecificType | null> {
    if (data.label) {
      data = { ...data, name: this.toCamelCase(data.label) };
    }
    return prisma.specificType.update({ where: { id }, data });
  }

  async remove(id: string): Promise<SpecificType | null> {
    return prisma.specificType.delete({ where: { id } });
  }

  async findOnlyWithAttributeNames(): Promise<SpecificType[] | null> {
    return prisma.specificType.findMany({
      where: {
        AttributeNames: {
          some: {},
        },
      },
    });
  }

  toCamelCase(str: string): string {
    str = str.toLowerCase();
    return str
      .replace(/(?:^|[^a-zA-Z])([a-zA-Z])/g, function (_, char) {
        return char.toUpperCase();
      })
      .replace(/\s+|\([^)]*\)/g, '')
      .replace(/\(|\)/g, '')
      .replace(/^([A-Z])/, function (char) {
        return char.toLowerCase();
      });
  }
}
