import { Test, TestingModule } from '@nestjs/testing';
import { SpecificTypeService } from './specific_type.service';

describe('SpecificTypeService', () => {
  let service: SpecificTypeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SpecificTypeService],
    }).compile();

    service = module.get<SpecificTypeService>(SpecificTypeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
