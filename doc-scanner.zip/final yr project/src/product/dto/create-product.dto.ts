export class ProductDto {
  id: string;
  partNo: string;
  description: string;
  manufacturer: string;
  specificTypeId: string;
  ProductSpecs: ProductSpecDto[];
}

export class ProductSpecDto {
  id: string;
  attributeNameId: string;
  value: string;
}

export class UpdateProductDto {
  partNo?: string;
  description?: string;
  manufacturer?: string;
  specificTypeId?: string;
  ProductSpecs?: ProductSpecDto[];
}

export class DeleteProductDto {
  id: string;
}
