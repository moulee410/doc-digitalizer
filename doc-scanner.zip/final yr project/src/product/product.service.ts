import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { ProductDto } from './dto/create-product.dto';

import * as XLSX from 'xlsx';
import * as path from 'path';

@Injectable()
export class ProductService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  async findAllProducts(page?, specificTypeId?): Promise<any> {
    if (specificTypeId === '') {
      const products = [];
      return { products };
    }
    const products = await this.prisma.product.findMany({
      where: {
        specificTypeId: specificTypeId,
      },
      include: { ProductSpecs: { include: { AttributeName: true } } },
      skip: (page - 1) * 20,
      take: 20,
    });
    for (const product of products) {
      const specificType = await this.prisma.specificType.findUnique({
        where: {
          id: product.specificTypeId,
        },
      });
      const subCategory = await this.prisma.subCategory.findUnique({
        where: {
          id: specificType.subCategoryId,
        },
      });
      const category = await this.prisma.category.findUnique({
        where: {
          id: subCategory.categoryId,
        },
      });
      (product as any).specificType = specificType;
      (product as any).subCategory = subCategory;
      (product as any).category = category;
    }
    const totalPage = Math.ceil(
      (await this.prisma.product.count({
        where: {
          specificTypeId: specificTypeId,
        },
      })) / 20,
    );
    return { products, totalPage };
  }

  async updateProduct(id: string, data: any): Promise<ProductDto> {
    try {
      const existingProduct = await this.prisma.product.findUnique({
        where: { id },
        include: { ProductSpecs: true },
      });

      if (!existingProduct) {
        throw new Error('Product not found');
      }

      const { ProductSpecs, ...productData } = data; // Destructure ProductSpecs from data

      if (ProductSpecs && ProductSpecs.length > 0) {
        // If ProductSpecs array is provided, update multiple attributes
        return await this.updateProductSpecs(id, ProductSpecs);
      } else {
        // If ProductSpecs array is not provided, update the product details
        const updatedProduct = await this.prisma.product.update({
          where: { id },
          data: {
            ...productData, // Spread remaining data
          },
          include: { ProductSpecs: true },
        });
        return updatedProduct;
      }
    } catch (error) {
      console.error('Error updating product:', error);
      throw new Error('Failed to update product');
    }
  }

  async updateProductSpecs(
    id: string,
    ProductSpecs: any[],
  ): Promise<ProductDto> {
    try {
      const updatedProduct = await this.prisma.product.update({
        where: { id },
        data: {
          ProductSpecs: {
            updateMany: ProductSpecs.map((spec) => ({
              where: { attributeNameId: spec.attributeNameId },
              data: { value: spec.value },
            })),
          },
        },
        include: { ProductSpecs: true },
      });
      return updatedProduct;
    } catch (error) {
      console.error('Error updating product specs:', error);
      throw new Error('Failed to update product specs');
    }
  }

  async deleteProduct(id: string): Promise<ProductDto> {
    await this.prisma.productSpec.deleteMany({
      where: {
        productId: id,
      },
    });

    const deletedProduct = await this.prisma.product.delete({
      where: {
        id,
      },
      include: {
        ProductSpecs: true,
      },
    });

    return deletedProduct;
  }

  async getExcelFile(id: string) {
    console.log(id);

    const products = await this.prisma.product.findMany({
      where: {
        specificTypeId: id,
      },
      include: {
        ProductSpecs: true,
      },
    });

    const attributes = await this.prisma.attributeName.findMany({
      where: {
        specificTypeId: id,
      },
    });

    const specificType = await this.prisma.specificType.findUnique({
      where: { id },
      include: { SubCategory: { include: { category: true } } },
    });

    const worksheet = XLSX.utils.aoa_to_sheet([]);
    const headers = [
      'Part No',
      'Manufacturer',
      'Description',
      'Specific Type',
      'Category',
      'SubCategory',
    ];
    const _headers = attributes.map((attribute) => attribute.label);
    const totalHeaders = [...headers, ..._headers];
    XLSX.utils.sheet_add_aoa(worksheet, [totalHeaders], { origin: 'A1' });

    products.forEach((product, index) => {
      const rowData = [
        product.partNo,
        product.manufacturer,
        product.description,
        specificType.label,
        specificType.SubCategory.category.label,
        specificType.SubCategory.label,
      ];
      attributes.forEach((attribute) => {
        const productSpec = product.ProductSpecs.find(
          (spec) => spec.attributeNameId === attribute.id,
        );
        rowData.push(productSpec ? productSpec.value : '-');
      });
      XLSX.utils.sheet_add_aoa(worksheet, [rowData], {
        origin: `A${index + 2}`,
      });
    });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Products');

    const fileName = `products_${id}.xlsx`;
    const filePath = path.join(__dirname, '..', 'downloads', fileName); // Construct file path
    XLSX.writeFile(workbook, filePath);
    console.log(`Excel file generated: ${filePath}`);
    return fileName;
  }
}
