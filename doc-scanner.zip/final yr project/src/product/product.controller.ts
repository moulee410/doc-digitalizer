import {
  Controller,
  Get,
  Put,
  Delete,
  Param,
  Body,
  Query,
  Post,
} from '@nestjs/common';
import { ProductService } from './product.service';
import { ProductDto } from './dto/create-product.dto';

@Controller('products')
export class ProductController {
  constructor(private readonly productService: ProductService) {}

  @Get()
  async findAllProducts(
    @Query('page') page?: any,
    @Query('specificTypeId') specificTypeId?: any,
  ): Promise<ProductDto[]> {
    return this.productService.findAllProducts(page, specificTypeId);
  }

  @Put(':id')
  async updateProduct(
    @Param('id') id: string,
    @Body() data: any,
  ): Promise<ProductDto> {
    try {
      const { ProductSpecs } = data;
      if (ProductSpecs) {
        return await this.productService.updateProductSpecs(id, ProductSpecs);
      } else {
        return await this.productService.updateProduct(id, data);
      }
    } catch (error) {
      console.log(error);
    }
  }

  @Delete(':id')
  async deleteProduct(@Param('id') id: string): Promise<ProductDto> {
    return this.productService.deleteProduct(id);
  }

  @Post('excel')
  async getExcelFile(@Body('specificTypeId') id: string): Promise<any> {
    try {
      return await this.productService.getExcelFile(id);
    } catch (error) {
      console.log(error);
    }
  }
}
