import { Body, Controller, HttpStatus, Post, Delete } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthDto } from './dto/auth.dto';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('Authentication')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @ApiOperation({
    summary: 'Sign In',
    description: 'Authenticate user and return JWT token',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully authenticated and retrieved JWT token',
  })
  @ApiResponse({
    status: 401,
    description: 'Invalid credentials',
  })
  @ApiBody({ type: AuthDto })
  @Post('signin')
  async signIn(@Body() body: AuthDto) {
    const token = await this.authService.signIn(body.email, body.password);
    if (!token) {
      return {
        statusCode: HttpStatus.UNAUTHORIZED,
        message: 'Invalid credentials',
      };
    }
    return token;
  }

  @ApiOperation({
    summary: 'Logout',
    description: 'Validate JWT token to log out user',
  })
  @ApiResponse({
    status: 200,
    description: 'Logged out successfully',
  })
  @ApiResponse({
    status: 400,
    description: 'Token is missing',
  })
  @ApiResponse({
    status: 401,
    description: 'Invalid token',
  })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        token: {
          type: 'string',
          description: 'JWT token to invalidate',
        },
      },
      required: ['token'],
    },
  })
  @Delete('logout')
  async logout(@Body() body) {
    const { token } = body;
    if (!token) {
      return {
        statusCode: HttpStatus.BAD_REQUEST,
        message: 'Token is missing',
      };
    }
    const result = await this.authService.signOut(token);
    if (result === 'OK') {
      return { statusCode: HttpStatus.OK, message: 'Logged out successfully' };
    }
    return { statusCode: HttpStatus.UNAUTHORIZED, message: 'Invalid token' };
  }
}
