import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class TasksService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (e) {
      console.log(e);
    }
  }

  async getTasks(page?: number) {
    if (!page) {
      const tasks = await this.prisma.task.findMany({
        orderBy: { createdAt: 'desc' },
        include: { SpecificType: true },
      });
      return { tasks };
    }
    const tasks = await this.prisma.task.findMany({
      orderBy: { createdAt: 'desc' },
      include: { SpecificType: true },
      skip: (page - 1) * 20,
      take: 20,
    });

    const totalPage = Math.ceil((await this.prisma.task.count()) / 20);
    const totalCount = await this.prisma.task.count();
    return { tasks, totalPage, totalCount };
  }

  async deleteTask(id: string) {
    return this.prisma.task.delete({ where: { id } });
  }
}
