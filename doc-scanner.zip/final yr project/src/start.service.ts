import { Injectable } from '@nestjs/common';
import { PrismaClient, RoleName } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import * as data from './metadata.json';
@Injectable()
export class StartService {
  private readonly prisma: PrismaClient;

  constructor() {
    this.prisma = new PrismaClient();
  }

  async createRolesAndSuperAdminUser(): Promise<void> {
    try {
      let superAdminRoleId: string | null = null;

      // Check if SuperAdmin role exists
      const existingSuperAdminRole = await this.prisma.role.findFirst({
        where: { name: RoleName.SuperAdmin },
      });

      // If SuperAdmin role does not exist, create all roles
      if (!existingSuperAdminRole) {
        // Create all roles
        const roles: RoleName[] = Object.values(RoleName);
        await this.prisma.role.createMany({
          data: roles.map((name) => ({ name })),
        });

        // Retrieve SuperAdmin role ID
        const createdSuperAdminRole = await this.prisma.role.findFirst({
          where: { name: RoleName.SuperAdmin },
        });
        if (createdSuperAdminRole) {
          superAdminRoleId = createdSuperAdminRole.id;
        } else {
          throw new Error('SuperAdmin role not created.');
        }
      } else {
        superAdminRoleId = existingSuperAdminRole.id;
      }

      const existingSuperAdminUser = await this.prisma.user.findFirst({
        where: { roleId: superAdminRoleId },
      });

      if (!existingSuperAdminUser) {
        const hashedPassword = await bcrypt.hash('superadmin', 10);
        await this.prisma.user.create({
          data: {
            name: 'Super Admin',
            password: hashedPassword,
            roleId: superAdminRoleId,
            mobileNo: '1234567890',
            email: 'superadmin@gmail.com',
          },
        });
      }

      const existingCategories = await this.prisma.category.findMany();
      if (existingCategories.length === 0) {
        await this.insertData();
      }
    } catch (error) {
      console.error('Error creating roles and Super Admin user:', error);
    } finally {
      await this.prisma.$disconnect();
    }
  }

  async insertData(): Promise<void> {
    const attributeNames = [
      {
        Aluminium_Electrolytic_Capacitors: [
          'name',
          'Type',
          'Series',
          'Capacitance',
          'Rated Voltage DC',
          'Tolerance',
          'Endurance (LIfe)',
          'Rated Ripple Current',
          'Leakage Current',
          'ESR',
          'Pitch',
          'Size (D x L)',
          'Operating Temperature',
          'Status',
          'Grade',
          'Mounting Style',
          'AEC Qualified',
          'Packing Style',
        ],
      },
      {
        ADC: [
          'name',
          'Sub Family',
          'General  Description',
          'No. of Channels',
          'Resolution (Bits)',
          'Sample rate (Max) (MSPS)',
          'Interface',
          'SFDR - Spurious Free Dynamic Range',
          'Signal to Noise Ratio - SNR - Typ',
          'Supply Voltage (Min)',
          'Supply Voltage (Max)',
          'Power consumption (Typ)',
          'Integral Non Linearity (INL)',
          'Differential Non Linearity (DNL)',
          'Features',
          'Operating Temperature Range',
          'Status',
          'Grade',
          'No. of Pins',
          'Packing Style',
          'Package',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        'Bipolar_Transistors - Bjt': [
          'name',
          'Type',
          'Polarity',
          'Collector Emitter Voltage',
          'Collector Base Voltage',
          'Emitter Base Voltage',
          'Collector Current',
          'Power Rating',
          'DC Collector/Base Gain hfe Min',
          'DC Current Gain hFE Max',
          'Operating Temperature Range',
          'Status',
          'Grade',
          'Mounting Style',
          'Package',
          'Supplier Package',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'Base Part No',
        ],
      },
      {
        Bridge_Rectifiers: [
          'name',
          'Type',
          'Repetitive Peak Reverse Voltage',
          'Average Rectified Current',
          'Forward Voltage Drop',
          'Maximum Reverse Current',
          'Maximum Peak Forward Surge Current',
          'Junction Temperature',
          'Recovery time',
          'Total Capacitance',
          'Status',
          'Grade',
          'Mounting Style',
          'Package',
          'Supplier Package',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'Base Part No',
        ],
      },
      {
        DDR4: [
          'name',
          'Density',
          'Organization',
          'Speed',
          'Supply Voltage',
          'Operating Temperature Range',
          'Grade',
          'Package',
          'Status',
          'ROHS',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        Fixed_Inductors: [
          'name',
          'Type',
          'Series',
          'Size/Case',
          'Inductance',
          'Tolerance',
          'Rated DC Current',
          'Q Min',
          'Self Resonant Frequency',
          'DC Resistance',
          'Operating Temperature Range',
          'Status',
          'Grade',
          'Shielded',
          'Mounting Style',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        IGBT: [
          'name',
          'Type',
          'Collector Emitter Voltage VCE',
          'Collector-Emitter Saturation Voltage',
          'Continuous collector current at TC = 25Â°C',
          'Continuous collector current at TC = 100Â°C',
          'Turn-on Switching Energy Eon',
          'Turn-off Switching Energy Eoff',
          'Power Dissipation',
          'Anti Parallel Diode',
          'Operating Temperature Range',
          'Status',
          'Grade',
          'Mounting Style',
          'Package',
          'Supplier Package',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        LDO_Regulator: [
          'name',
          'Type',
          'Polarity',
          'Min Input Voltage',
          'Max Input Voltage',
          'Min Output Voltage',
          'Max Output Voltage',
          'Output Voltage(Typ)',
          'Fixed Output Voltage',
          'Output Options',
          'Max Output Current',
          'Output Current Typ',
          'Output Tolerance',
          'Dropout Voltage',
          'Quiescent Current',
          'PSRR',
          'Features',
          'Operating Temperature',
          'Status',
          'Grade',
          'Mounting Style',
          'Package',
          'Supplier Package',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        MCU: [
          'name',
          'Core',
          'CPU Speed',
          'Operating Voltage (Min)',
          'Display Controller',
          'Package',
          'I/O Pins',
          '8-bit Timer',
          'A/D Converters 12-bit',
          'D/A Converters 12-bit',
          'I2C',
          'Operating Voltage (Max)',
          'Flash/Program Memory',
          'RAM Size',
          '16-bit Timer',
          'EEPROM',
          'CAN',
          'A/D Converters 10-bit',
          'No. of Comparators',
          'SPI',
          'UART',
          'Status',
          'Operating Frequency',
          'Mounting Style',
          'AEC Qualified',
          'AEC Qualified',
          'Packing Style',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        MLCCs: [
          'name',
          'Type',
          'Series',
          'Size/Case',
          'Capacitance',
          'Rated Voltage DC',
          'Dielectric',
          'Tolerance',
          'Operating Temperature',
          'Status',
          'Mounting Style',
          'AEC Qualified',
          'Termination',
          'Packing Style',
        ],
      },
      {
        MOSFET: [
          'name',
          'Polarity',
          'No. of Channels',
          'Construction Type',
          'Drain - Source Voltage',
          'Drain Current-Continuous',
          'RDS(ON) @ VGS=10V Max',
          'RDS(ON) @ VGS=4.5V Max',
          'RDS(ON)',
          'Gate-Source Voltage',
          'Power Dissipation',
          'Total Gate Charge',
          'Operating Temperature Range',
          'Grade',
          'Status',
          'Mounting Style',
          'Package',
          'Supplier Package',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'Base Part No',
        ],
      },
      {
        Standard_Comparators: [
          'name',
          'Type',
          'General  Description',
          'No. of Channels',
          'Supply Voltage (Min)',
          'Supply Voltage (Max)',
          'Supply Current per Channel (Typ)',
          'Response Time (Typ)',
          'Input Offset Voltage (Typ)',
          'Input Offset Voltage (Max)',
          'Input Bias Current (Typ)',
          'Rail to Rail Input',
          'Output Configuration',
          'Operating Temperature Range',
          'Status',
          'Grade',
          'Special Feature',
          'Mounting Style',
          'Package',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Budgetary Pricing',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'ROHS',
        ],
      },
      {
        Thin_Film_Resistors: [
          'name',
          'Type',
          'Series',
          'Size/Case',
          'Resistance',
          'Tolerance',
          'Power Rating',
          'TCR',
          'Max Working Voltage',
          'Max Overload Voltage',
          'Operating Temperature Range',
          'Grade',
          'Mounting Style',
          'AEC Qualified',
          'Status',
          'Termination',
          'Packing Style',
          'ROHS',
          'Packing Style',
          'Base Part No',
        ],
      },
      {
        Triacs: [
          'name',
          'Type',
          'Repetitive Peak Off-State  Voltage',
          'RMS on-state current - IT(RMS)',
          'Non repetitive Peak On-State Current - ITSM',
          'Gate Trigger Current - IGT',
          'Quadrants',
          'Junction Temperature',
          'Status',
          'Grade',
          'Mounting Style',
          'AEC Qualified',
          'Package',
          'Supplier Package',
          'Packing Style',
          'ROHS',
          'Package',
          'ROHS',
        ],
      },
      {
        TVS_Diodes: [
          'name',
          'Configuration',
          'Reverse Standoff Voltage',
          'Peak Pulse Power',
          'Power Rating',
          'Breakdown Voltage Typical',
          'Breakdown Voltage Min',
          'Breakdown Voltage Max',
          'Clamping Voltage',
          'Reverse Current',
          'Max Peak Current',
          'Voltage Tolerance',
          'Operating Temperature Range',
          'Status',
          'Grade',
          'Mounting Style',
          'Package',
          'Supplier Package',
          'AEC Qualified',
          'Packing Style',
          'ROHS',
          'Base Part No',
          'Package',
          'ROHS',
        ],
      },
    ];
    try {
      // Loop through each category
      for (const [categoryName, category] of Object.entries(data)) {
        const createdCategory = await this.prisma.category.create({
          data: {
            name: this.toCamelCase(categoryName),
            label: categoryName,
            description: category.Description,
          },
        });

        // Loop through each subcategory
        for (const [subCategoryName, subCategory] of Object.entries(category)) {
          if (
            typeof subCategory === 'object' &&
            subCategory !== null &&
            'Description' in subCategory
          ) {
            const subCategoryDescription = subCategory.Description;

            const createdSubCategory = await this.prisma.subCategory.create({
              data: {
                name: this.toCamelCase(subCategoryName),
                label: subCategoryName,
                description: subCategoryDescription,
                categoryId: createdCategory.id,
              },
            });

            // Check if 'SpecifyType' exists in subCategory
            if ('SpecifyType' in subCategory && subCategory.SpecifyType) {
              for (const [typeName, typeDescription] of Object.entries(
                subCategory.SpecifyType,
              )) {
                await this.prisma.specificType.create({
                  data: {
                    name: this.toCamelCase(typeName),
                    label: typeName,
                    description: typeDescription,
                    subCategoryId: createdSubCategory.id,
                  },
                });
              }
            }
          }
        }
      }

      for (const obj of attributeNames) {
        const firstKey = Object.keys(obj)[0];
        const specificType = await this.prisma.specificType.findFirst({
          where: {
            name: {
              endsWith: this.toCamelCase(firstKey),
              mode: 'insensitive',
            },
          },
        });

        if (specificType) {
          for (const attributeName of obj[firstKey]) {
            await this.prisma.attributeName.create({
              data: {
                specificTypeId: specificType.id,
                name: this.toCamelCase(attributeName),
                label: attributeName,
              },
            });
          }
        } else {
          console.error(`Specific type not found for ${firstKey}`);
        }
      }
    } catch (error) {
      console.error('Error inserting data:', error);
    }
  }
  toCamelCase(str: string): string {
    str = str.toLowerCase();
    return str
      .replace(/(?:^|[^a-zA-Z])([a-zA-Z])/g, function (_, char) {
        return char.toUpperCase();
      })
      .replace(/^([a-zA-Z])/, function (char) {
        return char.toLowerCase();
      })
      .replace(/\s+/g, '');
  }
}
