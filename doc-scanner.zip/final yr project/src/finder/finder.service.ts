import { HttpService } from '@nestjs/axios';
import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { AxiosError } from 'axios';
import { File } from 'multer';
import OpenAI from 'openai';
import * as PDFParser from 'pdf-parse';
import { catchError, firstValueFrom } from 'rxjs';
import {
  ATTRIBUTE_VALUE_PROMPT,
  CATEGORY_FINDER_PROMPT,
  COUNT_DEVICES_PROMPT,
} from './finder-propmts';

enum PartParsingStatus {
  INPROGRESS = 'INPROGRESS',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
}

@Injectable()
export class FinderService {
  private prisma: PrismaClient;

  constructor(private httpService: HttpService) {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }
  extractJsonFromMarkdown(mdContent: string) {
    console.log('Extraction called for ' + mdContent);

    const jsonRegex = /```json\s*([\s\S]*?)\s*```/;

    const match = mdContent.match(jsonRegex);
    console.log(match);

    if (match && match[1]) {
      try {
        const jsonString = match[1].trim();
        return JSON.parse(jsonString);
      } catch (e) {
        console.error('Failed to parse JSON:', e);
        return null;
      }
    } else {
      try {
        return JSON.parse(mdContent);
      } catch (error) {
        console.error('No JSON content found');
        return null;
      }
    }
  }

  async sendRequestToOpenAI(promptMessages) {
    try {
      const openai = new OpenAI({ apiKey: process.env.OPENAI_KEY });
      const model = process.env.OPENAI_MODEL;

      const completion = await openai.chat.completions.create({
        messages: promptMessages,
        model: model,
      });
      console.log(completion);

      return completion.choices[0].message.content
        ? this.extractJsonFromMarkdown(completion.choices[0].message.content)
        : null;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async findCategory(fileContent, categories) {
    let systemPrompt = CATEGORY_FINDER_PROMPT.replace(
      '{{categories}}',
      JSON.stringify(categories),
    );
    const promptMessages = [
      {
        role: 'system',
        content: systemPrompt,
      },
      {
        role: 'user',
        content: fileContent,
      },
    ];
    //let category = await this.sendRequestToOpenAI(promptMessages);
    let category = await this.sendRequestToCohere(promptMessages);

    return category;
  }

  async mapAttributes(attributeValues, attributeList) {
    const devices = [];
    const specificType = await this.prisma.specificType.findUnique({
      where: { id: attributeList[0].specificTypeId },
      include: {
        SubCategory: {
          include: { category: true },
        },
      },
    });
    for (let partNo in attributeValues) {
      const attributes = [];
      for (let attribute of attributeList) {
        if (
          attributeValues[partNo] &&
          attributeValues[partNo][attribute.id]?.value
        ) {
          attributes.push({
            name: attribute.name,
            value: attributeValues[partNo][attribute.id],
            ...attribute,
          });
        }
      }
      devices.push({
        attributeValues: attributes,
        category: specificType.SubCategory.category,
        subCategory: specificType.SubCategory,
        specificType: specificType,
        partNo: partNo,
        manufacturer: attributeValues[partNo]['manufacturer'],
        brand: attributeValues[partNo]['brand'],
      });
    }
    return devices;
  }

  async createResult(devices, fileContent) {
    let _devices = [];
    for (let device of devices) {
      try {
        let _device = await this.prisma.part.findFirst({
          where: { partNo: device.partNo },
        });
        if (_device) {
          _device = await this.prisma.part.update({
            data: {
              partNo: device.partNo,
              manufacturer: device.manufacturer,
              brand: device.brand,
              specificTypeId: device.specificType.id,
              result: JSON.stringify(device.attributeValues),
              datasheet: fileContent,
              status: PartParsingStatus.SUCCESS,
            },
            where: { partNo: device.partNo },
          });
        } else {
          _device = await this.prisma.part.create({
            data: {
              partNo: device.partNo,
              manufacturer: device.manufacturer,
              brand: device.brand,
              specificTypeId: device.specificType.id,
              result: JSON.stringify(device.attributeValues),
              datasheet: fileContent,
              status: PartParsingStatus.SUCCESS,
            },
          });
        }
        _devices.push(_device);
      } catch (error) {
        console.log(error);
      }
    }
    return _devices;
  }

  async findValues(fileContent, attributeList) {
    const chunks = await this.chunkText(fileContent, 30000);
    const countResp = await this.countDevices(chunks[0]);
    const _values = {};
    if (countResp && countResp.partNos && countResp.partNos.length > 0) {
      const partData = await this.prisma.part.findUnique({
        where: { partNo: countResp.partNos[0] },
      });
      if (partData) {
        return undefined;
      }
      for (let chunk of chunks) {
        const resp = await this.findValuesForPartNo(chunk, attributeList);
        if (resp) {
          for (let partNo of countResp.partNos) {
            _values[partNo] = {};
            _values[partNo]['partNo'] = partNo;
            _values[partNo]['manufacturer'] = countResp.manufacturer;
            _values[partNo]['brand'] = countResp.brandName;
            for (let attributeName in resp)
              _values[partNo][attributeName] =
                resp[attributeName] && resp[attributeName] != ''
                  ? resp[attributeName]
                  : _values[partNo][attributeName];
          }
        }
      }
    }
    const result = await this.mapAttributes(_values, attributeList);
    const _result = await this.createResult(result, fileContent);
    console.log(_result);
    return _result;
  }

  async findValuesForPartNo(fileChunk, attributes) {
    let attributeChunk = await this.attributeChunk(attributes);
    let result = {};

    for (let attributeChunkItem of attributeChunk) {
      let prompt = ATTRIBUTE_VALUE_PROMPT.replace(
        '{{attributeList}}',
        JSON.stringify(attributeChunkItem),
      ).replace('{{chunk}}', fileChunk);

      const promptMessages = [
        {
          role: 'system',
          content: prompt,
        },
      ];
      let deviceValues = await this.sendRequestToCohere(promptMessages);

      for (let attributeName in deviceValues)
        result[attributeName] =
          deviceValues[attributeName] &&
          deviceValues[attributeName]?.value?.value?.trim() !== ''
            ? deviceValues[attributeName]
            : result[attributeName];
    }

    return result;
  }

  async sendRequestToMistral(chatHistory: any[], retry = 1) {
    console.log('Preparing the Req: ', new Date());

    const apiKey = process.env.MISTRAL_API_KEY;
    const { data } = await firstValueFrom(
      this.httpService
        .post(
          'https://api.mistral.ai/v1/chat/completions',
          {
            model: process.env.MISTRAL_MODEL,
            messages: chatHistory,
            temperature: 0.7,
            top_p: 1,
            max_tokens: 5000,
            stream: false,
            safe_prompt: false,
            random_seed: 1337,
          },
          {
            headers: {
              Authorization: `Bearer ${apiKey}`,
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
          },
        )
        .pipe(
          catchError((error: AxiosError) => {
            console.error(error);
            throw 'An error happened!';
          }),
        ),
    );

    const reply = data.choices[0].message;
    console.log(data.usage);
    const outputTokens = reply.content.length / 4;
    console.log('Output Tokens: ' + outputTokens);
    try {
      return JSON.parse(reply.content);
    } catch (error) {
      if (retry < 3) {
        console.log('Retrying: ' + retry);
        return this.sendRequestToMistral(chatHistory, retry + 1);
      }
    }
  }

  async sendRequestToCohere(chatHistory: any[]) {
    const { data } = await firstValueFrom(
      this.httpService
        .post(
          'https://api.cohere.ai/v1/chat',
          {
            model: process.env.COHERE_MODEL,
            message: chatHistory[0].content,
          },
          {
            headers: {
              Authorization: `Bearer ${process.env.COHERE_API_KEY}`,
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
          },
        )
        .pipe(
          catchError((error: AxiosError) => {
            console.error(error);
            throw 'An error happened!';
          }),
        ),
    );

    try {
      return this.extractJsonFromMarkdown(data.text);
    } catch (error) {
      console.log(error);
      return await this.sendRequestToCohere(chatHistory);
    }
  }

  async processPdf(pdf: File): Promise<any> {
    const pdfText = await PDFParser(pdf.buffer).then((data) => data.text);
    const singleLineText = await pdfText.replace(/[\r\n]+/gm, ' ').trim();

    if (singleLineText) {
      console.log('Classifing Category');

      const categories = await this.prisma.category.findMany({
        select: { id: true, name: true },
      });
      const category = await this.findCategory(singleLineText, categories);

      if (category) {
        console.log('Classifing SubCategory');
        const subcategories = await this.prisma.subCategory.findMany({
          where: { categoryId: category.id },
        });
        const subCategory = await this.findCategory(
          singleLineText,
          subcategories,
        );

        if (subCategory) {
          console.log('Classifing SpecificType');
          const specificTypes = await this.prisma.specificType.findMany({
            where: { subCategoryId: subCategory.id },
          });
          const specificType = await this.findCategory(
            singleLineText,
            specificTypes,
          );

          if (specificType) {
            const attributeList = await this.prisma.attributeName.findMany({
              where: { specificTypeId: specificType.id },
            });

            // let _defaultAttributes = [];
            // for(const attribute of this.defaultAttributes){
            //   attribute.specificTypeId = specificType.id;
            //   _defaultAttributes.push(attribute);
            // }

            // attributeList.push(..._defaultAttributes);

            console.log('Finding Values');
            const deviceObj = await this.findValues(
              singleLineText,
              attributeList,
            );
            if (deviceObj) {
              return {
                category,
                subCategory,
                specificType,
                attributeValues: deviceObj,
              };
            }
          }
        }
      }
    }
  }

  async processPdfBySpecificType(
    pdf: File,
    specificTypeId: string,
  ): Promise<any> {
    const pdfText = await PDFParser(pdf.buffer).then((data) => data.text);
    const singleLineText = await pdfText.replace(/[\r\n]+/gm, ' ').trim();

    if (singleLineText) {
      const attributeList = await this.prisma.attributeName.findMany({
        where: { specificTypeId },
      });

      // let _defaultAttributes = [];
      // for(const attribute of this.defaultAttributes){
      //   attribute.specificTypeId = specificTypeId;
      //   _defaultAttributes.push(attribute);
      // }

      // attributeList.push(..._defaultAttributes);
      console.log('Finding Values');
      const deviceObj = await this.findValues(singleLineText, attributeList);
      if (deviceObj) {
        const specificType = await this.prisma.specificType.findUnique({
          where: { id: specificTypeId },
        });
        const subCategory = await this.prisma.subCategory.findUnique({
          where: { id: specificType.subCategoryId },
        });
        const category = await this.prisma.category.findUnique({
          where: { id: subCategory.categoryId },
        });
        return {
          category,
          subCategory,
          specificType,
          attributeValues: deviceObj,
        };
      }
    }
  }

  async addData(data: any) {
    const attributes = JSON.parse(data.result);
    const product = await this.prisma.product.create({
      data: {
        partNo: data.partNo || null,
        description: attributes?.attributeValues?.description || null,
        manufacturer: data.manufacturer || null,
        specificTypeId: data.specificTypeId,
      },
    });

    for (const attribute of attributes) {
      const attributeId = attribute.id;
      const attributeValue = attribute.value.value;
      const attributeUnit = attribute.value.unit || null;
      let valueWithUnit = String(attributeValue);
      if (attributeUnit) {
        valueWithUnit += ' ' + attributeUnit;
      }
      if (attributeId && attributeValue) {
        await this.prisma.productSpec.create({
          data: {
            productId: product.id,
            attributeNameId: attributeId,
            value: valueWithUnit,
          },
        });
      }
    }

    await this.prisma.part.delete({ where: { id: data.id } });
    return;
  }

  async countDevices(datasheetInfo) {
    const prompt = COUNT_DEVICES_PROMPT.replace(
      '{{datasheetInfo}}',
      datasheetInfo,
    );
    const response = await this.sendRequestToCohere([
      { role: 'system', content: prompt },
    ]);
    console.log(response);
    return response;
  }

  async chunkText(text: string, maxTokens: number) {
    // Split the text into sentences. This is a simple approach and might need refinement.
    const sentences = text.match(/[^\.!\?]+[\.!\?]+/g) || [];
    let currentChunk = '';
    const chunks: string[] = [];

    sentences.forEach((sentence) => {
      // Check if adding the next sentence would exceed the max token count
      if (currentChunk.length + sentence.length > maxTokens) {
        // If so, push the current chunk to the chunks array and start a new one
        chunks.push(currentChunk);
        currentChunk = sentence;
      } else {
        // If not, add the sentence to the current chunk
        currentChunk += sentence;
      }
    });

    // Don't forget to add the last chunk if it's not empty
    if (currentChunk) {
      chunks.push(currentChunk);
    }

    return chunks;
  }

  async attributeChunk(attributes) {
    let attributeChunk = [];
    let currentAttribute = [];
    for (let attribute of attributes) {
      if (currentAttribute.length === 20) {
        attributeChunk.push(currentAttribute);
        currentAttribute = [];
      }
      currentAttribute.push(attribute);
    }
    if (currentAttribute.length > 0) {
      attributeChunk.push(currentAttribute);
    }
    return attributeChunk;
  }

  async retryMissing(id: string) {
    const part = await this.prisma.part.findUnique({
      where: { id },
    });
    let result = JSON.parse(part.result);
    const actualAttributes = await this.prisma.attributeName.findMany({
      where: { specificTypeId: part.specificTypeId },
    });
    const resultAttributeIds = result.map((attr) => attr.id);
    const missingAttributes = actualAttributes.filter(
      (attr) => !resultAttributeIds.includes(attr.id),
    );

    console.log(missingAttributes);
    const fileContent = part.datasheet;
    const chunks = await this.chunkText(fileContent, 30000);
    for (const chunk of chunks) {
      const resp = await this.findValuesForPartNo(chunk, missingAttributes);
      if (resp) {
        for (let attribute of missingAttributes) {
          if (resp[attribute.id] && resp[attribute.id]?.value) {
            result.push({
              name: attribute.name,
              value: resp[attribute.id],
              ...attribute,
            });
            console.log(resp[attribute.id]);
            console.log(resp[attribute.id]?.value);
          }
        }
        console.log(result);
      }
    }

    await this.prisma.part.update({
      where: { id },
      data: { result: JSON.stringify(result) },
    });

    return;
  }
}
