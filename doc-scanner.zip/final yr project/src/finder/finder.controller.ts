import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { PrismaClient } from '@prisma/client';
import { File } from 'multer';
import { FinderService } from './finder.service';

@Controller('finder')
export class FinderController {
  private prisma: PrismaClient;

  constructor(private readonly finderService: FinderService) {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  @Post('uploadmany')
  @UseInterceptors(FileFieldsInterceptor([{ name: 'pdf', maxCount: 10 }]))
  async uploadPdfs(@UploadedFiles() files: { pdf?: File[] }) {
    if (!files || !files.pdf) {
      return { error: 'No files uploaded or empty PDF field' };
    }

    const pdfFiles: File[] = files.pdf.filter((file) => !!file);
    const results = [];
    const task = await this.prisma.task.create({
      data: { status: 'IN PROGRESS' },
    });
    let allFilesProcessedFailed = true;
    for (const file of pdfFiles) {
      try {
        const result = await this.finderService.processPdf(file);
        allFilesProcessedFailed = false;
        results.push(result);
      } catch (error) {
        console.log(error);
        continue;
      }
    }
    if (allFilesProcessedFailed) {
      await this.prisma.task.update({
        where: { id: task.id },
        data: { status: 'FAILED' },
      });
    } else {
      await this.prisma.task.delete({ where: { id: task.id } });
    }
    return results;
  }
  @Post('uploadmanywithtype')
  @UseInterceptors(FileFieldsInterceptor([{ name: 'pdf', maxCount: 10 }]))
  async uploadPdfsWithType(
    @UploadedFiles() files: { pdf?: File[] },
    @Body('specifictypeid') specifictypeid: string,
  ) {
    if (!files || !files.pdf) {
      return { error: 'No files uploaded or empty PDF field' };
    }

    const pdfFiles: File[] = files.pdf.filter((file) => !!file);
    const results = [];

    console.log(pdfFiles.length);

    let allFilesProcessedFailed = true;

    const failedPDFs: string[] = [];
    const filenames = pdfFiles.map((file) => file.originalname);
    const task = await this.prisma.task.create({
      data: {
        status: 'IN PROGRESS',
        pdfs: filenames.join(','),
        specificTypeId: specifictypeid,
      },
    });
    for (const file of pdfFiles) {
      try {
        const result = await this.finderService.processPdfBySpecificType(
          file,
          specifictypeid,
        );
        results.push(result);
        allFilesProcessedFailed = false;
      } catch (error) {
        failedPDFs.push(file.originalname);
        continue;
      }
    }
    if (allFilesProcessedFailed) {
      await this.prisma.task.update({
        where: { id: task.id },
        data: { status: 'FAILED' },
      });
    } else {
      await this.prisma.task.delete({ where: { id: task.id } });
    }
    return results;
  }

  @Post('add')
  async addToDatabase(@Body() data: any) {
    return await this.finderService.addData(data);
  }

  @Post('addmany')
  async addManyToDatabase(@Body() datas: any[]) {
    for (const data of datas) {
      await this.finderService.addData(data);
    }
    return;
  }

  @Post('missing')
  async getMissingData(@Body('id') id: string) {
    const part = await this.prisma.part.update({
      where: { id },
      data: { status: 'INPROGRESS' },
    });
    try {
      const result = await this.finderService.retryMissing(id);
    } catch (error) {
      await this.prisma.part.update({
        where: { id },
        data: { status: 'FAILED' },
      });
      return;
    }
    await this.prisma.part.update({
      where: { id },
      data: { status: 'SUCCESS' },
    });
    return;
  }
}
