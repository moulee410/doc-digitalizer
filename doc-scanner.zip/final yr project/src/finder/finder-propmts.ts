

export const CATEGORY_FINDER_PROMPT = `You will be provided with the datasheet details of a semiconductor 
device you have to classify its category as 
{{categories}}

Your output should only be a json object which is only one category classified as per the datasheet.`;

export const ATTRIBUTE_VALUE_FINDER_PROMPT = `You will be provided with a datasheet details of a semiconductor
device you need to find the values for the given attributes 
{{attributeList}}

your output should only be a json object which contains the values for the given attributes.

Remember you should provide values for the given attributes only, the values should be single and direct values.
`;

export const COUNT_DEVICES_PROMPT = `You are provided with the datasheet info of a semiconductor devices.
Your task is to find the number of seminconductor devices covered in the datasheet and 
provide the partNos & manufacturer info of those devices in the following format,

{
    "total": "no.of devices"
    "partNos": [
        "partNo1",
        "partNo2",
        "partNo3"
    ],
    "manufacturer": "Name of the manufacturer",
    "brandName": "Name of the brand"
} 

Never forgot you should return only in JSON Format don't add any extra text in your response.

Here is the Datasheet info,
###
{{datasheetInfo}}
###
`;

export const ATTRIBUTE_VALUE_PROMPT = `You will be provided with a chunk of datasheet details of a semiconductor
device. There might be more than one device in the chunk you need to find the values for the given attributes.

Here are the attributes:
###
{{attributeList}}
###


Here is the chuk:
###
{{chunk}}
###

You should return the values in the given format,

{
    "attribute1id": {
        "value": "value for the current attribute1",
        "unit": "unit for the current attribute1",
        "name": "name of the attribute"
    },
    "attribute2id": {
        "value": "value for the current attribute2",
        "unit": "unit for the current attribute2",
        "name": "name of the attribute"
    },
    "attribute3id": {
        "value": "value for the current attribute3",
        "unit": "unit for the current attribute3",
        "name": "name of the attribute"
    },
}

Remember unit should be exact unit like V, KV, mV.

Value should not include units.

Never forgot you should return only in JSON Format don't add any extra text in your response.`;






