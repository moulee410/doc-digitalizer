interface CategoryDTO {
  id: string;
  name: string;
  label: string;
  description: string;
  createdAt: Date;
  updatedAt: Date;
}

interface SubCategoryDTO {
  id: string;
  name: string;
  label: string;
  description: string;
  categoryId: string;
  createdAt: Date;
  updatedAt: Date;
}

interface SpecificTypeDTO {
  id: string;
  name: string;
  label: string;
  description: string;
  subCategoryId: string;
  createdAt: Date;
  updatedAt: Date;
}

interface AttributeValuesDTO {
  [key: string]: string;
}

export interface addData {
  category: CategoryDTO;
  subCategory: SubCategoryDTO;
  specificType: SpecificTypeDTO;
  
  attributeValues: AttributeValuesDTO;
}
