export class SubCategoryDto {
  id: string;
  name: string;
  label: string;
  description: string;
  categoryId: string;
}
