import { IsNotEmpty, IsString } from 'class-validator';

export class CreateSubCategoryDto {
  @IsString()
  label: string;

  @IsString()
  description: string;

  @IsNotEmpty()
  @IsString()
  categoryId: string;
}
