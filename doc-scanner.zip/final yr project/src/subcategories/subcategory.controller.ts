import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { SubCategoryService } from './subcategory.service';
import { CreateSubCategoryDto } from './dto/create-subcategory.dto';
import { SubCategoryDto } from './dto/subcategory.dto';

@Controller('subcategories')
export class SubCategoryController {
  constructor(private readonly subCategoryService: SubCategoryService) {}

  @Post()
  async create(@Body() createSubCategoryDto: CreateSubCategoryDto) {
    await this.subCategoryService.create(createSubCategoryDto);
    return { statusCode: HttpStatus.CREATED };
  }

  @Get()
  async findAll(@Query('page') page?: any): Promise<SubCategoryDto[]> {
    return await this.subCategoryService.findAll(
      page ? parseInt(page) : undefined,
    );
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<SubCategoryDto> {
    return await this.subCategoryService.findOne(id);
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() updateSubCategoryDto: any) {
    await this.subCategoryService.update(id, updateSubCategoryDto);
    return { statusCode: HttpStatus.OK };
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.subCategoryService.remove(id);
    return { statusCode: HttpStatus.NO_CONTENT };
  }
}
