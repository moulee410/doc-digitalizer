import { Injectable, HttpStatus } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { CreateSubCategoryDto } from './dto/create-subcategory.dto';
import { SubCategoryDto } from './dto/subcategory.dto';

@Injectable()
export class SubCategoryService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  async create(data: CreateSubCategoryDto): Promise<any> {
    const value = { ...data, name: this.toCamelCase(data.label) };
    try {
      await this.prisma.subCategory.create({ data: value });
      return { statusCode: HttpStatus.CREATED };
    } catch (error) {
      console.error('Error creating subcategory:', error);
      throw new Error('Could not create subcategory');
    }
  }

  async findAll(page?: number): Promise<any> {
    if (!page) {
      const subCategories = await this.prisma.subCategory.findMany();
      return { subCategories };
    }
    const subCategories = await this.prisma.subCategory.findMany({
      skip: (page - 1) * 20,
      take: 20,
    });

    const totalPage = Math.ceil((await this.prisma.subCategory.count()) / 20);
    return { subCategories, totalPage };
  }

  async findOne(id: string): Promise<SubCategoryDto> {
    return await this.prisma.subCategory.findUnique({ where: { id } });
  }

  async update(id: string, data: any): Promise<any> {
    if (data.label) {
      data = { ...data, name: this.toCamelCase(data.label) };
    }
    try {
      await this.prisma.subCategory.update({ where: { id }, data });
      return { statusCode: HttpStatus.OK };
    } catch (error) {
      console.error('Error updating subcategory:', error);
      throw new Error('Could not update subcategory');
    }
  }

  async remove(id: string): Promise<any> {
    try {
      await this.prisma.subCategory.delete({ where: { id } });
      return { statusCode: HttpStatus.NO_CONTENT };
    } catch (error) {
      console.error('Error deleting subcategory:', error);
      throw new Error('Could not delete subcategory');
    }
  }
  toCamelCase(str: string): string {
    str = str.toLowerCase();
    return str
      .replace(/(?:^|[^a-zA-Z])([a-zA-Z])/g, function (_, char) {
        return char.toUpperCase();
      })
      .replace(/\s+|\([^)]*\)/g, '')
      .replace(/\(|\)/g, '')
      .replace(/^([A-Z])/, function (char) {
        return char.toLowerCase();
      });
  }
}
