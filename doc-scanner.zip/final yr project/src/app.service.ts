import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return `Semisearch App is running!`;
  }

  getHealth() : any {
    return {
      status: true,
      heath: 'OK'
    }
  }
}
