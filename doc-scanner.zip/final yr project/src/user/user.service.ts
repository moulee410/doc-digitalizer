import { HttpStatus, Injectable } from '@nestjs/common';
import { AddUserDto } from './dto/adduser.dto';
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import { UserDto } from './dto/user.dto';
import { UpdateUserDto } from './dto/updateuser.dto';

@Injectable()
export class UserService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  async addUser(adduserdto: AddUserDto): Promise<any> {
    const hashedpassword = await bcrypt.hash(adduserdto.password, 10);
    await this.prisma.user.create({
      data: { ...adduserdto, password: hashedpassword },
    });
    return { statusCode: HttpStatus.CREATED };
  }

  async getUsers(limit?: number, page?: number, filter?: any): Promise<any> {
    if (limit) {
      delete filter?.limit;
    }
    if (page) {
      delete filter?.page;
    }

    let whereCondition: any = {};

    // Filter conditions
    if (filter) {
      if (filter.gender) {
        const gender = filter.gender.toLowerCase();
        if (gender === 'male' || gender === 'female' || gender === 'others') {
          whereCondition.gender = gender;
        }
      }

      whereCondition = {
        ...whereCondition,
        AND: Object.keys(filter).map((key) => {
          if (typeof filter[key] === 'string') {
            return {
              [key]: {
                contains: filter[key],
                mode: 'insensitive',
              },
            };
          } else {
            return {
              [key]: filter[key],
            };
          }
        }),
      };
    }
    whereCondition = {
      ...whereCondition,
      role: {
        NOT: {
          name: 'SuperAdmin',
        },
      },
    };
    const usersQuery: any = {
      where: whereCondition,
      include: { role: true },
    };

    if (page !== undefined && limit !== undefined) {
      const offset = (page - 1) * limit;
      usersQuery.skip = offset;
      usersQuery.take = limit;
    }

    const users = await this.prisma.user.findMany(usersQuery);

    const totalCount = await this.prisma.user.count({ where: whereCondition });
    const totalPage =
      page !== undefined && limit !== undefined
        ? Math.ceil(totalCount / limit)
        : 1;

    return { users, totalPage };
  }

  async getVolunteers(
    limit?: number,
    page?: number,
    filter?: any,
  ): Promise<any> {
    let whereCondition: any[] = [
      {
        role: {
          name: 'Volunteer',
        },
      },
    ];

    if (limit) {
      delete filter.limit;
    }

    if (page) {
      delete filter.page;
    }

    if (filter) {
      if (filter.gender) {
        const gender = filter.gender.toLowerCase();
        if (gender === 'male' || gender === 'female' || gender === 'others') {
          whereCondition.push({ gender });
        } else {
          delete filter.gender;
        }
      }

      const filterConditions = Object.keys(filter).map((key) => {
        if (typeof filter[key] === 'string') {
          return {
            [key]: { contains: filter[key], mode: 'insensitive' },
          };
        } else {
          return {
            [key]: filter[key],
          };
        }
      });
      whereCondition = [...whereCondition, ...filterConditions];
    }

    const volunteersQuery = {
      where: {
        AND: whereCondition,
      },
      include: { role: true },
    };

    if (page !== undefined && limit !== undefined) {
      const offset = (page - 1) * limit;
      volunteersQuery['skip'] = offset;
      volunteersQuery['take'] = limit;
    }

    const volunteers = await this.prisma.user.findMany(volunteersQuery);

    const totalCount = await this.prisma.user.count({
      where: { AND: whereCondition },
    });
    const totalPage =
      page !== undefined && limit !== undefined
        ? Math.ceil(totalCount / limit)
        : 1;

    return { volunteers, totalPage };
  }

  async getAgents(limit?: number, page?: number, filter?: any): Promise<any> {
    let whereCondition: any[] = [
      {
        role: {
          name: 'Agent',
        },
      },
    ];

    // Adjusting for the 'limit' parameter
    if (limit) {
      // Delete 'limit' property from the filter
      delete filter.limit;
    }

    // Adjusting for the 'page' parameter
    if (page) {
      // Delete 'page' property from the filter
      delete filter.page;
    }

    if (filter) {
      // Handling filter conditions
      if (filter.gender) {
        // Assuming gender filter is applicable for agents
        const gender = filter.gender.toLowerCase();
        if (gender === 'male' || gender === 'female' || gender === 'others') {
          whereCondition.push({ gender });
        } else {
          delete filter.gender;
        }
      }

      // General filter conditions
      const filterConditions = Object.keys(filter).map((key) => {
        if (typeof filter[key] === 'string') {
          return {
            [key]: { contains: filter[key], mode: 'insensitive' },
          };
        } else {
          return {
            [key]: filter[key],
          };
        }
      });
      whereCondition = [...whereCondition, ...filterConditions];
    }

    const agentsQuery = {
      where: {
        AND: whereCondition,
      },
      include: { role: true },
    };

    if (page !== undefined && limit !== undefined) {
      const offset = (page - 1) * limit;
      agentsQuery['skip'] = offset;
      agentsQuery['take'] = limit;
    }

    const agents = await this.prisma.user.findMany(agentsQuery);

    const totalCount = await this.prisma.user.count({
      where: { AND: whereCondition },
    });
    const totalPage =
      page !== undefined && limit !== undefined
        ? Math.ceil(totalCount / limit)
        : 1;

    return { agents, totalPage };
  }

  async getSingleUser(userId: string): Promise<any> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { role: true },
    });
    return user;
  }

  async updateUser(userId: string, updatedata: UpdateUserDto): Promise<object> {
    await this.prisma.user.update({
      where: {
        id: userId,
      },
      data: updatedata,
    });
    return { statusCode: HttpStatus.OK };
  }

  async deleteUser(userId: string): Promise<object> {
    await this.prisma.user.delete({ where: { id: userId } });
    return { statusCode: HttpStatus.NO_CONTENT };
  }
}
