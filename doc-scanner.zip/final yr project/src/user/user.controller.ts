import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { AddUserDto } from './dto/adduser.dto';
import { UserService } from './user.service';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { UserDto, UsersResponseDto } from './dto/user.dto';
import { UpdateUserDto } from './dto/updateuser.dto';

@ApiTags('Users')
@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @ApiOperation({
    summary: 'Add new user',
    description: 'Adds a new user to the database',
  })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Successfully created a user',
  })
  @ApiBody({ type: AddUserDto })
  @Post()
  async addUser(@Body() addUserDto: AddUserDto) {
    await this.userService.addUser(addUserDto);
    return { statusCode: HttpStatus.CREATED };
  }

  @ApiOperation({
    summary: 'Get all users',
    description: 'Retrieves all users from the database',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully fetched the users',
    type: UsersResponseDto,
  })
  @Get()
  async getUsers(
    @Query('limit') limit: string = '5',
    @Query('page') page?: string,
    @Query() filter?: any,
  ): Promise<UserDto[]> {
    return await this.userService.getUsers(
      limit ? parseInt(limit) : undefined,
      page ? parseInt(page) : undefined,
      filter,
    );
  }

  @ApiOperation({
    summary: 'Get volunteers',
    description: 'Retrieves volunteers from the database',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully fetched the volunteers',
    type: UsersResponseDto,
  })
  @Get('volunteers')
  async getVolunteers(
    @Query('limit') limit: string = '5',
    @Query('page') page?: string,
    @Query() filter?: any,
  ): Promise<UserDto[]> {
    return await this.userService.getVolunteers(
      limit ? parseInt(limit) : undefined,
      page ? parseInt(page) : undefined,
      filter,
    );
  }

  @ApiOperation({
    summary: 'Get agents',
    description: 'Retrieves agents from the database',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully fetched the agents',
    type: UsersResponseDto,
  })
  @Get('agents')
  async getAgents(
    @Query('limit') limit: string = '5',
    @Query('page') page?: string,
    @Query() filter?: any,
  ): Promise<UserDto[]> {
    return await this.userService.getAgents(
      limit ? parseInt(limit) : undefined,
      page ? parseInt(page) : undefined,
      filter,
    );
  }

  @ApiOperation({
    summary: 'Get single user',
    description: 'Retrieves a particular user from the database',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully fetched the user',
    type: UserDto,
  })
  @Get(':userId')
  async getSingleUser(@Param('userId') userId: string): Promise<UserDto> {
    return await this.userService.getSingleUser(userId);
  }

  @ApiOperation({
    summary: 'Update user',
    description: 'Updates a user in the database',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully updated the user',
  })
  @Put(':userId')
  async updateUser(
    @Param('userId') userId: string,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    await this.userService.updateUser(userId, updateUserDto);
    return { statusCode: HttpStatus.OK };
  }

  @ApiOperation({
    summary: 'Delete user',
    description: 'Deletes a user from the database',
  })
  @ApiResponse({
    status: HttpStatus.NO_CONTENT,
    description: 'Successfully deleted the user',
  })
  @Delete(':userId')
  async deleteUser(@Param('userId') userId: string) {
    await this.userService.deleteUser(userId);
    return { statusCode: HttpStatus.NO_CONTENT };
  }
}
