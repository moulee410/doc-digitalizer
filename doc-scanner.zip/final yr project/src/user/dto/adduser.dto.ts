import { ApiProperty } from '@nestjs/swagger';

export class AddUserDto {
  @ApiProperty()
  public roleId: string;
  @ApiProperty()
  public password: string;
  @ApiProperty()
  public name: string;
  @ApiProperty()
  public mobileNo: string;
  @ApiProperty()
  public email: string;
}
