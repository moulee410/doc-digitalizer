import { ApiProperty } from '@nestjs/swagger';

export class UpdateUserDto {
  @ApiProperty({ required: false })
  roleId?: string;
  @ApiProperty({ required: false })
  name?: string;
  @ApiProperty({ required: false })
  mobileNo?: string;
  @ApiProperty({ required: false })
  email?: string;
}
