import {
  Injectable,
  NestMiddleware,
  UnauthorizedException,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { decodeJwtToken } from 'src/util';

@Injectable()
export class AuthMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      throw new UnauthorizedException('Authorization token is missing');
    }

    const payload = decodeJwtToken(token);
    if (!payload || !payload.userId) {
      throw new UnauthorizedException(
        'Invalid token ' + token + ' payload: ' + payload,
      );
    }

    req['user'] = payload;

    next();
  }
}
