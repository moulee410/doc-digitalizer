import { HttpStatus, Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { AttributeNamesDto } from './dto/attribute-names.dto';
import { UpdateAttributeNameDto } from './dto/update-attribute-name.dto';

@Injectable()
export class AttributeNamesService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  async addAttributeName(attributeNameDto: AttributeNamesDto): Promise<any> {
    const specificTypeId = attributeNameDto.specificTypeId;
    const attributeNames = attributeNameDto.attributeNames;
    for (const attribute of attributeNames) {
      const data = {
        name: this.toCamelCase(attribute.label),
        label: attribute.label,
        description: attribute.description,
        specificTypeId: specificTypeId,
      };
      console.log(await this.prisma.attributeName.create({ data }));
    }

    return { statusCode: HttpStatus.CREATED };
  }

  async getAttributeNames(page?: any, specificTypeId?: any): Promise<any> {
    if (!specificTypeId) {
      const attributeNames = await this.prisma.attributeName.findMany();
      return { attributeNames };
    }
    if (!page) {
      const attributeNames = await this.prisma.attributeName.findMany({
        where: { specificTypeId },
      });
      return { attributeNames };
    }
    const attributeNames = await this.prisma.attributeName.findMany({
      where: { specificTypeId },
      skip: (page - 1) * 20,
      take: 20,
    });
    const totalPage = Math.ceil(
      (await this.prisma.attributeName.count({ where: { specificTypeId } })) /
        20,
    );
    return { attributeNames, totalPage };
  }

  async getSingleAttributeName(id: string): Promise<any> {
    return await this.prisma.attributeName.findUnique({
      where: { id: id },
    });
  }

  async updateAttributeName(
    id: string,
    attributeNameDto: UpdateAttributeNameDto,
  ): Promise<object> {
    let data;
    if (attributeNameDto.label) {
      data = {
        ...attributeNameDto,
        name: this.toCamelCase(attributeNameDto.label),
      };
    } else {
      data = attributeNameDto;
    }
    await this.prisma.attributeName.update({
      where: {
        id: id,
      },
      data,
    });
    return { statusCode: HttpStatus.OK };
  }

  async deleteAttributeName(id: string): Promise<object> {
    await this.prisma.attributeName.delete({ where: { id: id } });
    return { statusCode: HttpStatus.NO_CONTENT };
  }
  toCamelCase(str: string): string {
    str = str.toLowerCase();
    return str
      .replace(/(?:^|[^a-zA-Z])([a-zA-Z])/g, function (_, char) {
        return char.toUpperCase();
      })
      .replace(/\s+|\([^)]*\)/g, '')
      .replace(/\(|\)/g, '')
      .replace(/^([A-Z])/, function (char) {
        return char.toLowerCase();
      });
  }
}
