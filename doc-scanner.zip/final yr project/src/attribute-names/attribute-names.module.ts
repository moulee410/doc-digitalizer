import { Module } from '@nestjs/common';
import { AttributeNamesService } from './attribute-names.service';
import { AttributeNamesController } from './attribute-names.controller';

@Module({
  providers: [AttributeNamesService],
  controllers: [AttributeNamesController]
})
export class AttributeNamesModule {}
