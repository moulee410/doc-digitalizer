import { Test, TestingModule } from '@nestjs/testing';
import { AttributeNamesController } from './attribute-names.controller';

describe('AttributeNamesController', () => {
  let controller: AttributeNamesController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AttributeNamesController],
    }).compile();

    controller = module.get<AttributeNamesController>(AttributeNamesController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
