class SingleAttribute {
  label: string;
  description?: string;
}

export class AttributeNamesDto {
  specificTypeId: string;
  attributeNames: SingleAttribute[];
}
