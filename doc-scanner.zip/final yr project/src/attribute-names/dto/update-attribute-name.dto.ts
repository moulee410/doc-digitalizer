export class UpdateAttributeNameDto {
  label?: string;
  description?: string;
  specificTypeId?: string;
}
