import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { AttributeNamesService } from './attribute-names.service';
import { AttributeNamesDto } from './dto/attribute-names.dto';
import { UpdateAttributeNameDto } from './dto/update-attribute-name.dto';

@Controller('attributenames')
export class AttributeNamesController {
  constructor(private readonly attributeNamesService: AttributeNamesService) {}

  @Post()
  async addAttributeName(@Body() attributeNameDto: AttributeNamesDto) {
    await this.attributeNamesService.addAttributeName(attributeNameDto);
    return { statusCode: HttpStatus.CREATED };
  }

  @Get()
  async getAttributeNames(
    @Query('page') page?: any,
    @Query('specificTypeId') specificTypeId?: any,
  ): Promise<AttributeNamesDto[]> {
    return await this.attributeNamesService.getAttributeNames(
      page ? parseInt(page) : undefined,
      specificTypeId,
    );
  }

  @Get(':id')
  async getSingleAttributeName(
    @Param('id') id: string,
  ): Promise<AttributeNamesDto> {
    return await this.attributeNamesService.getSingleAttributeName(id);
  }

  @Put(':id')
  async updateAttributeName(
    @Param('id') id: string,
    @Body() attributeNameDto: UpdateAttributeNameDto,
  ) {
    await this.attributeNamesService.updateAttributeName(id, attributeNameDto);
    return { statusCode: HttpStatus.OK };
  }

  @Delete(':id')
  async deleteAttributeName(@Param('id') id: string) {
    await this.attributeNamesService.deleteAttributeName(id);
    return { statusCode: HttpStatus.NO_CONTENT };
  }
}
