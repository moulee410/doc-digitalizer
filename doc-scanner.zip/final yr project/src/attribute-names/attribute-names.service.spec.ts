import { Test, TestingModule } from '@nestjs/testing';
import { AttributeNamesService } from './attribute-names.service';

describe('AttributeNamesService', () => {
  let service: AttributeNamesService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AttributeNamesService],
    }).compile();

    service = module.get<AttributeNamesService>(AttributeNamesService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
