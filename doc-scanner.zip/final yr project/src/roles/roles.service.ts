import { Injectable } from '@nestjs/common';
import { PrismaClient, Role as PrismaRole } from '@prisma/client';
import { RoleDto } from './dto/role.dto';
import { RoleName } from './dto/role.enum';

@Injectable()
export class RolesService {
  private readonly prisma: PrismaClient;

  constructor() {
    this.prisma = new PrismaClient();
  }

  async getRoles(): Promise<any> {
    const role: PrismaRole[] = await this.prisma.role.findMany();

    const returnRoles = role.map((role) => ({
      id: role.id,
      name: role.name as RoleName,
    }));

    return { roles: returnRoles };
  }
}
