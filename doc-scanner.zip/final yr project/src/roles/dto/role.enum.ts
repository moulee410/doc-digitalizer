export enum RoleName {
  SuperAdmin = 'SuperAdmin',
  Admin = 'Admin',
  User = 'User',
}
