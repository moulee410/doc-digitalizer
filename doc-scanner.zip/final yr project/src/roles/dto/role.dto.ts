import { ApiProperty } from '@nestjs/swagger';
import { RoleName } from './role.enum';

export class RoleDto {
  @ApiProperty()
  id: string;

  @ApiProperty({
    enum: ['SuperAdmin', 'Admin', 'User'],
  })
  name: RoleName;
}

export class RoleResponseDto {
  @ApiProperty({ type: [RoleDto] })
  roles: RoleDto[];
}
