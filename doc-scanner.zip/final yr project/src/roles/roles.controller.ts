import { Controller, Get } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RoleDto, RoleResponseDto } from './dto/role.dto';
import { RolesService } from './roles.service';

@ApiTags('Roles')
@Controller('roles')
export class RolesController {
  constructor(private readonly roleService: RolesService) {}

  @ApiOperation({
    summary: 'Get all roles',
    description: 'Retrieves all roles from the database',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched the roles',
    type: RoleResponseDto,
  })
  @Get()
  async getRoles(): Promise<RoleDto[]> {
    return await this.roleService.getRoles();
  }
}
