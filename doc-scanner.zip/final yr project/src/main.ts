import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import * as cors from 'cors';
import * as fs from 'fs'; // Import fs for file system operations
import * as path from 'path'; // Import path
import { AppModule } from './app.module';
import { StartService } from './start.service';

async function bootstrap() {
  console.log(process.env.DATABASE_URL);
  console.log(process.env.MISTRAL_API_KEY);
  console.log(process.env.MISTRAL_MODEL);
  console.log(process.env.COHERE_API_KEY);
  console.log(process.env.COHERE_MODEL);
  console.log(process.env.REACT_APP_PORTURL);

  const downloadsFolderPath = path.join(__dirname, 'downloads');
  if (!fs.existsSync(downloadsFolderPath)) {
    fs.mkdirSync(downloadsFolderPath);
    console.log('Downloads folder created successfully');
  }
  const app = await NestFactory.create(AppModule);
  app.use(cors());
  app.setGlobalPrefix('api');

  const config = new DocumentBuilder()
    .setTitle('semisearch')
    .setDescription('Semi Conductor')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);
  const startService = new StartService();
  await startService.createRolesAndSuperAdminUser();

  await app.listen(3001);
}
bootstrap();
