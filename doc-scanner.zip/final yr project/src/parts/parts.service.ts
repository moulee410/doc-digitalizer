import { Injectable } from '@nestjs/common';
import { PrismaClient, SpecificType } from '@prisma/client';

@Injectable()
export class PartsService {
  private prisma: PrismaClient;

  constructor() {
    try {
      this.prisma = new PrismaClient();
    } catch (error) {
      console.error('Error initializing PrismaClient:', error);
    }
  }

  async getParts(page?: number) {
    if (!page) {
      const parts = await this.prisma.part.findMany({
        orderBy: { updatedAt: 'desc' },
      });

      for (let part of parts) {
        const specificType = await this.prisma.specificType.findUnique({
          where: { id: part.specificTypeId },
        });
        const subCategory = await this.prisma.subCategory.findUnique({
          where: { id: specificType.subCategoryId },
          include: { category: true },
        });
        (part as any).specificType = specificType;
        (part as any).subCategory = subCategory;
        (part as any).category = subCategory.category;
        delete part.datasheet;
      }
      return { parts };
    }
    const parts = await this.prisma.part.findMany({
      skip: (page - 1) * 20,
      take: 20,
      orderBy: { updatedAt: 'desc' },
    });

    for (let part of parts) {
      const specificType = await this.prisma.specificType.findUnique({
        where: { id: part.specificTypeId },
      });
      const subCategory = await this.prisma.subCategory.findUnique({
        where: { id: specificType.subCategoryId },
        include: { category: true },
      });
      (part as any).specificType = specificType;
      (part as any).subCategory = subCategory;
      (part as any).category = subCategory.category;
      delete part.datasheet;
    }

    const totalPage = Math.ceil((await this.prisma.part.count()) / 20);
    const totalCount = await this.prisma.part.count();

    return { parts, totalPage, totalCount };
  }

  async getMissingParts(id: string) {
    const part = await this.prisma.part.findUnique({
      where: { id },
    });
    const result = JSON.parse(part.result);
    const actualAttributes = await this.prisma.attributeName.findMany({
      where: { specificTypeId: part.specificTypeId },
    });
    const resultAttributeIds = result.map((attr) => attr.id);

    const missingAttributes = actualAttributes.filter(
      (attr) => !resultAttributeIds.includes(attr.id),
    );

    return missingAttributes;
  }

  async deleteParts(id: string) {
    await this.prisma.part.delete({
      where: { id },
    });
    return;
  }
}
