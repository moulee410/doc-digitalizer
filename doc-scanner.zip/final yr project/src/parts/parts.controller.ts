import { Controller, Delete, Get, Param, Query } from '@nestjs/common';
import { PartsService } from './parts.service';

@Controller('parts')
export class PartsController {
  constructor(private readonly partsService: PartsService) {}

  @Get()
  async findall(@Query('page') page?: any) {
    return this.partsService.getParts(page ? parseInt(page) : undefined);
  }

  @Get('missing/:id')
  async findMissing(@Param('id') id: string) {
    return this.partsService.getMissingParts(id);
  }
  @Delete(':id')
  async deleteAll(@Param('id') id: string) {
    return this.partsService.deleteParts(id);
  }
}
