import React from "react";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

function EditModal({ showModal, handleClose, handleSaveEdit, label, handleLabelChange, description, handleDescriptionChange, specificTypeId, handleSpecificTypeIdChange, attributenames, editData }) {
  return (
    <Modal show={showModal} onHide={handleClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Edit Attribute Name</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group controlId="formLabel">
            <Form.Label>Name</Form.Label>
            <Form.Control
              type="text"
              value={label}
              onChange={handleLabelChange}
            />
          </Form.Group>
          <Form.Group controlId="formDescription">
            <Form.Label>Description</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              value={description}
              onChange={handleDescriptionChange}
            />
          </Form.Group>
          <Form.Group controlId="formSpecificTypeId">
            <Form.Label>Specific Type</Form.Label>
            <Form.Control
              as="select"
              value={specificTypeId}
              onChange={handleSpecificTypeIdChange}
            >
              <option value="">Select Specific Type</option>
              {attributenames.map((specificType) => (
                <option
                  key={specificType.id}
                  value={specificType.id}
                >
                  {specificType.name}
                </option>
              ))}
            </Form.Control>
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          {" "}
          Close{" "}
        </Button>
        <Button variant="primary" onClick={handleSaveEdit}>
          {" "}
          Save Changes{" "}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default EditModal;
