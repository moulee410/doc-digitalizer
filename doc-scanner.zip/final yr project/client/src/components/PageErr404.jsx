import React from 'react';
import { Link } from 'react-router-dom';

function PageErr404() {
  return (
    <div
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        height: '50vh',
        flexDirection: 'column',
      }}
      className="d-flex"
    >
      <div>
        <h1 style={{ fontSize: '10rem', color: '#D20062' }}>404</h1>
      </div>
      <div>
        <h1 style={{ fontSize: '2rem' }}>File Not Found</h1>
      </div>

      <Link to={'/upload'}> <button className="px-4 p-2 text-light mt-3" style={{ border: ' none',backgroundColor:'#D20062' }}>
        Go To Home Page
      </button>
      </Link>
    </div>
  );
}

export default PageErr404;
