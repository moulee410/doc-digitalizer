import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import More from './More.png';
import './overflow.css';
import Pagination from '@mui/material/Pagination';
import { message } from 'antd';

function Category() {
  const [data, setData] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [description, setDescription] = useState('');
  const [label, setLabel] = useState('');
  const [selectedData, setSelectedData] = useState(null);
  const [refresh, setRefresh] = useState(false);
  const [editData, setEditData] = useState(null);
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);

  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + `/categories?page=${page}`)
      .then((response) => {
        setData(response.data.categories);
        setTotalPage(response.data.totalPage);
      })
      .catch(() => {
        message.error('Server Error');
      });
  }, [page, refresh]);

  const handleClose = () => {
    setShowModal(false);
    resetForm();
  };

  const resetForm = () => {
    setDescription('');
    setLabel('');
    setEditData(null);
    setSelectedData(null);
  };

  const handleShow = () => {
    setShowModal(true);
    resetForm();
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleLabelChange = (e) => {
    setLabel(e.target.value);
  };

  const handleAddCategory = (e) => {
    e.preventDefault();
    let payload = {
      description: description,
      label: label,
    };
    axios
      .post(process.env.REACT_APP_PORTURL + '/categories', payload)
      .then(() => {
        console.log('Category data sent');
        setRefresh(!refresh);
        message.success('Data added successfully');
      })
      .catch((err) => {
        message.error('Server Error');
      });

    handleClose();
  };

  const handleEdit = (data) => {
    setEditData(data);
    setDescription(data.description);
    setLabel(data.label);
    setShowModal(true);
  };

  const handleView = (data) => {
    setSelectedData(data);
    setShowModal(true);
  };

  const handleDelete = (data) => {
    axios
      .delete(process.env.REACT_APP_PORTURL + '/categories/' + data.id)
      .then((res) => {
        console.log('Category deleted successfully');
        setRefresh(!refresh);
      })
      .catch((err) => {
        console.log(err);
        message.error('Server Error');
      });
  };

  const handleSaveEdit = () => {
    let val = {};
    if (editData.description !== description) {
      val = { ...val, description };
    }
    if (editData.label !== label) {
      val = { ...val, label };
    }
    axios
      .put(process.env.REACT_APP_PORTURL + '/categories/' + editData.id, val)
      .then(() => {
        console.log('Category data updated');
        setRefresh(!refresh);
      })
      .catch(() => {
        console.log('Error updating category data');
        message.error('Server Error');
      });

    handleClose();
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  return (
    <div className="pb-4">
      <div
        style={{
          height: '80vh',
          position: 'relative',
          backgroundColor: 'white',
          margin: '0 3%',
        }}
        className="rounded-3 mt-3 p-2"
      >
        <div className="box p-1">
          <div
            style={{
              alignItems: 'center',
              width: '100%',
              justifyContent: 'space-between',
              paddingRight: '5%',
            }}
            className="d-flex gap-2 "
          >
            <div>
              <h4 style={{ fontWeight: 'bold' }}>Category</h4>
            </div>
            <button onClick={handleShow} className="btn btn-primary">
              Create
            </button>
          </div>
          <hr></hr>
          <div
            style={{
              position: 'relative',
              height: '67vh',
              overflowY: 'auto',
            }}
            className="table mt-3 "
          >
            <table className="table">
              <thead
                style={{
                  position: 'sticky',
                  top: 0,
                  backgroundColor: 'hsl(202, 100%, 77%)',
                }}
              >
                <tr>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>Name</th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>Description</th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}></th>
                </tr>
              </thead>
              <tbody>
                {data?.map((data, index) => (
                  <tr key={index}>
                    <td
                      className="truncate"
                      data-bs-placement="top"
                      title="Tooltip on top"
                    >
                      {data.label}
                    </td>
                    <td className="truncate">{data.description}</td>
                    <td>
                      <div style={{ textAlign: 'center' }}>
                        <img
                          className="dropdown-toggle"
                          type="button"
                          id="dropdownMenuButton1"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                          src={More}
                          alt=""
                        />
                        <ul
                          className="dropdown-menu p-2  rounded"
                          aria-labelledby="dropdownMenuButton1"
                        >
                          <li className=" rounded-1 drophover">
                            {' '}
                            <button
                              style={{
                                background: 'transparent',
                                border: 'none',
                                color: '',
                              }}
                              onClick={() => handleView(data)}
                            >
                              View
                            </button>
                          </li>
                          <li className=" rounded-1 drophover text-success">
                            <button
                              style={{
                                background: 'transparent',
                                border: 'none',
                                color: 'green',
                              }}
                              onClick={() => handleEdit(data)}
                            >
                              Update
                            </button>
                          </li>
                          <li className=" rounded-1 drophover text-danger">
                            <button
                              style={{
                                background: 'transparent',
                                border: 'none',
                                color: 'red',
                              }}
                              onClick={() => handleDelete(data)}
                            >
                              Delete
                            </button>
                          </li>
                        </ul>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <Modal show={showModal} onHide={handleClose} centered>
              <Modal.Header closeButton>
                <Modal.Title>
                  {selectedData
                    ? 'Category Details'
                    : editData
                      ? 'Edit Category'
                      : 'Add Category'}
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                {selectedData ? (
                  <div>
                    <p>
                      <strong>Name:</strong> {selectedData.label}
                    </p>
                    <p>
                      <strong>Description:</strong> {selectedData.description}
                    </p>
                  </div>
                ) : (
                  <Form>
                    <Form.Group controlId="formLabel">
                      <Form.Label>Name</Form.Label>
                      <Form.Control
                        type="text"
                        value={label}
                        onChange={handleLabelChange}
                      />
                    </Form.Group>
                    <Form.Group controlId="formDescription">
                      <Form.Label>Description</Form.Label>
                      <Form.Control
                        as="textarea"
                        rows={3}
                        value={description}
                        onChange={handleDescriptionChange}
                      />
                    </Form.Group>
                  </Form>
                )}
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  {' '}
                  Close{' '}
                </Button>
                {selectedData ? null : editData ? (
                  <Button variant="success" onClick={handleSaveEdit}>
                    {' '}
                    Save Changes{' '}
                  </Button>
                ) : (
                  <Button variant="success" onClick={handleAddCategory}>
                    {' '}
                    Save{' '}
                  </Button>
                )}
              </Modal.Footer>
            </Modal>
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-center mt-2 ">
        <Pagination
          count={totalPage}
          page={page}
          onChange={handlePageChange}
          shape="rounded"
          color="primary"
        />
      </div>
    </div>
  );
}

export default Category;
