import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import AddModal from './AddAttribute';
import EditModal from './EditAttribute';
import More from './More.png';

import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { message } from 'antd';

function Attributenames() {
  const [data, setData] = useState([]);
  const [attributenames, setAttributenames] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [description, setDescription] = useState('');
  const [label, setLabel] = useState('');
  const [specificTypeId, setSpecificTypeId] = useState('');
  const [specificType, setSpecificType] = useState([]);
  const [selectedData, setSelectedData] = useState(null);
  const [refresh, setRefresh] = useState(false);
  const [editData, setEditData] = useState(null);
  const [additionalFields, setAdditionalFields] = useState([
    { label: '', description: '' },
  ]);
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);
  const [selectedSpecificTypeId, setSelectedSpecificTypeId] = useState('');
  const [serialNumber, setSerialNumber] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    if (selectedSpecificTypeId) {
      axios
        .get(process.env.REACT_APP_PORTURL + `/attributenames`, {
          params: {
            specificTypeId: selectedSpecificTypeId,
          },
        })
        .then((response) => {
          setData(response?.data?.attributeNames);
        })
        .catch(() => {
          console.log('error in attributenames');
          message.error('Server Error');
        });
    }
  }, [refresh, selectedSpecificTypeId]);

  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/specifictypes')
      .then((response) => {
        setAttributenames(response?.data?.specificTypes);
      })
      .catch(() => {
        message.error('Server Error');
      });
  }, []);

  useEffect(() => {
    axios
      .get(
        process.env.REACT_APP_PORTURL + '/specifictypes/onlywithattributenames',
      )
      .then((response) => {
        setSpecificType(response.data);
      })
      .catch(() => {
        console.log('error in specific types');
        message.error('Server Error');
      });
  }, []);

  const handleCloseAddModal = () => {
    setShowAddModal(false);
    resetForm();
  };

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    resetForm();
  };

  const handleCloseViewModal = () => {
    setShowViewModal(false);
    setSelectedData(null);
  };

  const resetForm = () => {
    setDescription('');
    setLabel('');
    setEditData(null);
  };

  const handleShowAddModal = () => {
    setShowAddModal(true);
    resetForm();
  };

  const handleShowEditModal = (data) => {
    setEditData(data);

    setDescription(data.description);
    setLabel(data.label);
    setSpecificTypeId(data.specificTypeId);
    setShowEditModal(true);
  };

  const handleShowViewModal = (data) => {
    setSelectedData(data);
    setShowViewModal(true);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleLabelChange = (e) => {
    setLabel(e.target.value);
  };

  const handleSpecificTypeIdChange = (e) => {
    setSpecificTypeId(e.target.value);
  };

  const handleAddAttributeName = (e) => {
    e.preventDefault();

    axios
      .post(process.env.REACT_APP_PORTURL + '/attributenames', {
        specificTypeId,
        attributeNames: additionalFields,
      })
      .then((res) => {
        setRefresh(!refresh);
        setAdditionalFields([{ label: '', description: '' }]);
        message.success('Data Added Successfully');
      })
      .catch((err) => {
        console.log(err);
        message.error('Server Error');
      });

    handleCloseAddModal();
  };

  const handleDelete = (data) => {
    axios
      .delete(process.env.REACT_APP_PORTURL + '/attributenames/' + data.id)
      .then(() => {
        setRefresh(!refresh);
        message.success('Data Deleted Successfully');
      })
      .catch((err) => {
        console.log(err);
        message.error('Server Error');
      });
  };

  const handleSaveEdit = () => {
    let val = {};
    if (editData.description !== description) {
      val = { ...val, description };
    }
    if (editData.label !== label) {
      val = { ...val, label };
    }
    if (editData.specificTypeId !== specificTypeId) {
      val = { ...val, specificTypeId };
    }
    axios
      .put(
        process.env.REACT_APP_PORTURL + '/attributenames/' + editData.id,
        val,
      )
      .then(() => {
        console.log('Attribute name data updated');
        setRefresh(!refresh);
      })
      .catch(() => {
        console.log('Error updating attribute name data');
        message.error('Server Error');
      });

    handleCloseEditModal();
  };

  const getSpecificTypeNameById = (specificTypeId) => {
    const specificType = attributenames.find(
      (specificType) => specificType.id === specificTypeId,
    );
    return specificType ? specificType.label : '';
  };

  const handleAdditionalNameChange = (index, value) => {
    const updatedFields = [...additionalFields];
    updatedFields[index].name = value;
    setAdditionalFields(updatedFields);
  };

  const handleAdditionalDescriptionChange = (index, value) => {
    const updatedFields = [...additionalFields];
    updatedFields[index].description = value;
    setAdditionalFields(updatedFields);
  };

  const handleAutocompleteChange = (event, value) => {
    if (value) {
      setSpecificTypeId(value.id);
      setSelectedSpecificTypeId(value.id);
      setRefresh(!refresh);
    } else {
      setSelectedSpecificTypeId('');
    }
  };
  return (
    <div className="pb-4">
      <div
        style={{
          height: '85vh',
          position: 'relative',
          backgroundColor: 'white',
          margin: '0 3%',
        }}
        className="rounded-3 mt-3 p-2"
      >
        <div className="box p-1 ">
          <div
            style={{
              alignItems: 'center',
              width: '100%',
              justifyContent: 'space-between',
              paddingRight: '5%',
            }}
            className="d-flex gap-2 "
          >
            <h4 style={{ fontWeight: 'bold' }}>Attributes</h4>

            <div
              style={{
                display: 'flex',
                width: '75%',
                justifyContent: 'flex-end',
                alignItems: 'center',
                gap: '5%',
              }}
            >
              <Autocomplete
                disablePortal
                id="combo-box-demo"
                options={specificType || []}
                className={screenWidth < 992 ? 'w-100' : 'w-25'}
                getOptionLabel={(option) => option?.label}
                onChange={handleAutocompleteChange}
                clearIcon={null}
                renderInput={(params) => (
                  <TextField {...params} label="Select Specific Type" />
                )}
                sx={{
                  '& .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline':
                    {
                      borderColor: 'blue',
                    },
                  '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline':
                    {
                      borderColor: 'blue',
                    },
                }}
              />
              <button onClick={handleShowAddModal} className="btn btn-primary">
                Create
              </button>
            </div>
          </div>
          <hr></hr>
          <div
            style={{
              position: 'relative',
              height: '63vh',
              overflowY: 'auto',
            }}
            className="table mt-3 "
          >
            <table className="table">
              <thead
                style={{
                  position: 'sticky',
                  top: 0,
                  zIndex: '99',
                  backgroundColor: 'hsl(202, 100%, 77%)',
                }}
              >
                <tr>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>S.No</th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>Name</th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>Specific Type</th>
                  <th
                    className="description"
                    style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}
                  >
                    Description
                  </th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}></th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(data) &&
                  data.map((data, index) => (
                    <tr key={index}>
                      <td
                        className="truncate"
                        data-bs-placement="top"
                        title="Tooltip on top"
                      >
                        {serialNumber + index}
                      </td>
                      <td
                        className="truncate"
                        data-bs-placement="top"
                        title="Tooltip on top"
                      >
                        {data.label}
                      </td>
                      <td className="truncate">
                        {getSpecificTypeNameById(data.specificTypeId)}
                      </td>
                      <td className="truncate description">
                        {data.description}
                      </td>

                      <td>
                        <div className="dropdown">
                          <img
                            className="dropdown-toggle"
                            type="button"
                            id="dropdownMenuButton1"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            src={More}
                            alt=""
                          />
                          <ul
                            className="dropdown-menu p-2  rounded"
                            aria-labelledby="dropdownMenuButton1"
                          >
                            <li className=" rounded-1 drophover">
                              {' '}
                              <button
                                style={{
                                  background: 'transparent',
                                  border: 'none',
                                  color: '',
                                }}
                                onClick={() => handleShowViewModal(data)}
                              >
                                View
                              </button>
                            </li>
                            <li className=" rounded-1 drophover text-primary">
                              <button
                                style={{
                                  background: 'transparent',
                                  border: 'none',
                                  color: 'green',
                                }}
                                onClick={() => handleShowEditModal(data)}
                              >
                                Update
                              </button>
                            </li>
                            <li className=" rounded-1 drophover text-danger">
                              <button
                                style={{
                                  background: 'transparent',
                                  border: 'none',
                                  color: 'red',
                                }}
                                onClick={() => handleDelete(data)}
                              >
                                Delete
                              </button>
                            </li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <AddModal
        showModal={showAddModal}
        handleClose={handleCloseAddModal}
        handleAddAttributeName={handleAddAttributeName}
        specificTypeId={specificTypeId}
        handleSpecificTypeIdChange={handleSpecificTypeIdChange}
        attributenames={attributenames}
        additionalFields={additionalFields}
        setAdditionalFields={setAdditionalFields}
        handleAdditionalNameChange={handleAdditionalNameChange}
        handleAdditionalDescriptionChange={handleAdditionalDescriptionChange}
      />

      <EditModal
        showModal={showEditModal}
        handleClose={handleCloseEditModal}
        handleSaveEdit={handleSaveEdit}
        label={label}
        handleLabelChange={handleLabelChange}
        description={description}
        handleDescriptionChange={handleDescriptionChange}
        specificTypeId={specificTypeId}
        handleSpecificTypeIdChange={handleSpecificTypeIdChange}
        attributenames={attributenames}
        editData={editData}
      />

      <Modal show={showViewModal} onHide={handleCloseViewModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Attribute Name Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedData && (
            <div>
              <p>
                <strong>Name:</strong> {selectedData.label}
              </p>
              <p>
                <strong>Description:</strong> {selectedData.description}
              </p>
              <p>
                <strong>Specific Type ID:</strong>{' '}
                {getSpecificTypeNameById(selectedData.specificTypeId)}
              </p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseViewModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default Attributenames;
