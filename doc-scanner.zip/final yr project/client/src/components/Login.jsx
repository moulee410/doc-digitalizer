import React, { useState } from 'react';
import './Login.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import logo from './logo.png';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import { message } from 'antd';

const Login = ({ setLoggedIn }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isChecked, setIsChecked] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const toggleCheckbox = () => {
    setIsChecked(!isChecked);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleLogin = (event) => {
    event.preventDefault();
    axios
      .post(process.env.REACT_APP_PORTURL + '/auth/signin', { email, password })
      .then((res) => {
        if (res.data.token) {
          localStorage.setItem('token', res.data.token);
          setLoggedIn(true);
          navigate('/upload');
        } else {
          alert('Invalid Credentials');
        }
        
      })
      .catch((err)=>{
        message.error("NetWork Error")
      })
      

    setEmail('');
    setPassword('');
  };

  return (
    <section className="background-radial-gradient">
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}
        className="p-5"
      >
        <div className="row gx-lg-5 align-items-center">
          <div className="col-lg-6 mb-lg-0" style={{ zIndex: 10 }}>
            <img src={logo} className="w-50" alt="" />
            <h2
              className="mt-2 display-5 fw-bold ls-tight"
              style={{ color: 'black' }}
            >
              Search Semiconductors with AI
              <span className="text-primary fw-bold display-5">
                {' '}
                Semi Search
              </span>
            </h2>
          </div>

          <div className="col-lg-6 mb-5 mb-lg-0 position-relative">
            <div
              id="radius-shape-1"
              className="position-absolute rounded-circle shadow-5-strong"
            ></div>
            <div
              id="radius-shape-2"
              className="position-absolute shadow-5-strong"
            ></div>

            <div className="card bg-glass">
              <div className="card-body px-4 py-5 px-md-5">
                <form onSubmit={handleLogin}>
                  <div className="form-outline mb-4">
                    <center>
                      <h2>Login</h2>
                    </center>
                    <label className="form-label" htmlFor="form3Example3">
                      Email address
                    </label>
                    <input
                      type="email"
                      id="form3Example3"
                      className="form-control"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>

                  <div className="form-outline mb-4">
                    <label className="form-label" htmlFor="form3Example4">
                      Password
                    </label>
                    <div className="input-group">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        id="form3Example4"
                        className="form-control"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                      <button
                        className="btn btn-outline-primary"
                        type="button"
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? <FaEyeSlash /> : <FaEye />}
                      </button>
                    </div>
                  </div>

                  <div className="form-check mb-4">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="form2Example33"
                      checked={isChecked}
                      onChange={toggleCheckbox}
                    />
                    <label
                      className="form-check-label"
                      htmlFor="form2Example33"
                    >
                      Remember me
                    </label>
                  </div>

                  <div className="container">
                    <div className="row justify-content-center">
                      <div className="col-auto">
                        <button
                          type="submit"
                          className="btn btn-primary btn-block mb-4"
                        >
                          Login
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;
