import { CloseCircleOutlined, SyncOutlined } from '@ant-design/icons';
import { red } from '@mui/material/colors';
import {
  faEye,
  faFloppyDisk,
  faRotateRight,
  faTrashCan,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Modal, Tag, message } from 'antd';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import './Display.css';
import './check.css';
import { Pagination } from '@mui/material';
import logo from './logo.png';

function Display({ refresh, setRefresh, showTask, setShowTask }) {
  const [part, setPart] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedPart, setSelectedPart] = useState(null);
  const [missingAttribute, setMissingAttribute] = useState([]);
  const [openRetryModal, setOpenRetryModal] = useState(false);
  const [retryPart, setRetryPart] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [taskCount, setTaskCount] = useState(0);
  const [partCount, setPartCount] = useState(0);
  const [partpage, setPartpage] = useState(1);
  const [totalPartPage, setTotalPartPage] = useState(1);
  const [taskpage, setTaskpage] = useState(1);
  const [totalTaskPage, setTotalTaskPage] = useState(1);
  
  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/tasks', {
        params: { page: partpage },
      })
      .then((res) => {
        setTasks(res.data.tasks);
        setTotalTaskPage(res.data.totalPage);
        setTaskCount(res.data.totalCount);
      })
      .catch((err) => {
        console.log(err);
      });
  }, [refresh]);

  const handleViewDetails = async (content) => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/parts/missing/' + content.id)
      .then((res) => {
        setMissingAttribute(res.data);
      })
      .catch((err) => message.error(err.message));
    setSelectedPart(content);
    setModalVisible(true);
  };
  const formatCreatedAt = (dateString) => {
    const date = new Date(dateString);
    const formattedDate = `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
    const AM = date.getHours() < 12 ? true : false;
    const hours = date.getHours() % 12 || 12;
    const minutes =
      date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    const formattedTime = `${hours}:${minutes} ${AM ? 'AM' : 'PM'}`;
    return `${formattedDate} ${formattedTime}`;
  };
  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/parts', {
        params: { page: partpage },
      })
      .then((res) => {
        setPart(res.data.parts);
        setTotalPartPage(res.data.totalPage);
        setPartCount(res.data.totalCount);
      })
      .catch((err) => {
        message.error('Server Error');
      });
  }, [refresh]);

  const handleSavePart = (part) => {
    axios
      .post(process.env.REACT_APP_PORTURL + '/finder/add', part)
      .then((res) => {
        console.log(res.data);
        setRefresh(!refresh);
        message.success('Data saved successfully');
      })
      .catch((err) => {
        message.error('Server Error');
      });
  };

  const handleRefresh = () => {
    setRefresh(!refresh);
  };

  const handleDeletePart = (part) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You are about to delete this part. This action cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#75be75',
      cancelButtonColor: 'rgb(230 107 107)',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        axios
          .delete(process.env.REACT_APP_PORTURL + '/parts/' + part.id)
          .then(() => {
            setRefresh(!refresh);
            message.success('Data deleted successfully');
          })
          .catch((err) => {
            message.error('Server Error');
          });
      }
    });
  };

  const handleRetryOpen = (part) => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/parts/missing/' + part.id)
      .then((res) => {
        setMissingAttribute(res.data);
      })
      .catch((err) => message.error(err.message));
    setRetryPart(part);
    setOpenRetryModal(true);
  };

  const handleRetryClose = () => {
    setOpenRetryModal(false);
    setRetryPart(null);
  };

  const handleRetry = () => {
    axios
      .post(process.env.REACT_APP_PORTURL + '/finder/missing', {
        id: retryPart.id,
      })
      .then((res) => {
        setRetryPart(null);
        setRefresh(!refresh);
      })
      .catch((err) => {
        message.error('Server Error');
      });
    setRefresh(!refresh);
    setOpenRetryModal(false);
  };

  const handleDeleteTask = (task) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You are about to delete this task. This action cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#75be75',
      cancelButtonColor: 'rgb(230 107 107)',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        axios
          .delete(process.env.REACT_APP_PORTURL + '/tasks/' + task.id)
          .then(() => {
            setRefresh(!refresh);
            message.success('Task deleted successfully');
          })
          .catch((err) => {
            message.error('Server Error');
          });
      }
    });
  };

  const handleTaskPageChange = (event, value) => {
    setPartpage(value);
  };

  const handlePartPageChange = (event, value) => {
    setTaskpage(value);
  };

  return (
    <div>
      <div style={{ position: 'sticky', top: '0' }}>
        <nav className="mini-nav border ">
          <ul>
            <li
              className={showTask ? 'active' : ''}
              onClick={() => setShowTask(true)}
              style={{ textAlign: 'center' }}
            >
              Task
            </li>
            <li
              className={!showTask ? 'active' : ''}
              onClick={() => setShowTask(false)}
              style={{ textAlign: 'center' }}
            >
              Completed
            </li>
          </ul>
        </nav>
      </div>
      <div
        style={{
          width: '100%',
          height: '78vh',
          overflow: 'auto',
          backgroundColor: 'white',
        }}
        className="px-3"
      >
        {/* Navigation Bar */}

        {/* Content */}
        <div style={{ height: '100%' }}>
          {!showTask ? (
            <div style={{ height: '100%' }}>
              <div
                style={{ top: '0', position: 'sticky', background: 'white' }}
                className="d-flex align-items-center justify-content-between p-2"
              >
                <span>TotalCount : {partCount}</span>
                <i
                  style={{ cursor: 'pointer' }}
                  onClick={handleRefresh}
                  className="fa-solid fa-rotate-right"
                ></i>
              </div>
              {part?.length !== 0 ? (
                <div style={{ height: '100%' }}>
                  {Array.isArray(part) &&
                    part?.map((content, index) => (
                      <div key={index}>
                        <div
                          style={{
                            width: '100%',
                            transition: 'height 5s in-ease-out',
                            height: 'fit-content',
                          }}
                          className={`border rounded p-3 border-primary mt-2`}
                        >
                          <div className="cart">
                            <div style={{ width: '100%' }}>
                              <div
                                style={{
                                  display: 'flex',
                                  justifyContent: 'space-between',
                                  marginBottom: '10px',
                                }}
                                className="displaybtn"
                              >
                                <div
                                  style={{
                                    fontWeight: 'bolder',
                                    color: '#11009E',
                                  }}
                                >
                                  Processed At :{' '}
                                  {formatCreatedAt(content.updatedAt)}
                                </div>
                                {content.status === 'SUCCESS' ? (
                                  <div className="d-flex gap-2 display-icon">
                                    <div>
                                      <button
                                        onClick={() => handleRetryOpen(content)}
                                        className="btn btn-outline-secondary"
                                      >
                                        <FontAwesomeIcon icon={faRotateRight} />{' '}
                                        <span className="para">Retry</span>
                                      </button>
                                    </div>
                                    <div>
                                      <button
                                        onClick={() => handleSavePart(content)}
                                        className="btn btn-outline-success"
                                      >
                                        <FontAwesomeIcon icon={faFloppyDisk} />{' '}
                                        <span className="para">Save</span>
                                      </button>
                                    </div>

                                    <div>
                                      <button
                                        onClick={() =>
                                          handleDeletePart(content)
                                        }
                                        className="btn btn-outline-danger "
                                      >
                                        <FontAwesomeIcon icon={faTrashCan} />{' '}
                                        <span className="para">Delete</span>
                                      </button>
                                    </div>
                                    <div>
                                      <button
                                        onClick={() =>
                                          handleViewDetails(content)
                                        }
                                        className="btn btn-outline-primary"
                                      >
                                        <FontAwesomeIcon icon={faEye} />{' '}
                                        <span className="para">View</span>
                                      </button>
                                    </div>
                                  </div>
                                ) : content.status === 'INPROGRESS' ? (
                                  <div>
                                    {' '}
                                    <Tag
                                      color="blue"
                                      icon={<SyncOutlined spin />}
                                    >
                                      Finding Missing Attributes
                                    </Tag>
                                  </div>
                                ) : (
                                  <div className="d-flex gap-2 display-icon">
                                    <div>
                                      {' '}
                                      <Tag
                                        color="error"
                                        icon={<CloseCircleOutlined />}
                                      >
                                        {content?.status}
                                      </Tag>
                                    </div>
                                    <div>
                                      <button
                                        onClick={() =>
                                          handleDeletePart(content)
                                        }
                                        className="btn btn-outline-danger"
                                        style={{
                                          height: '25px',
                                          padding: '0 10px',
                                        }}
                                      >
                                        <FontAwesomeIcon icon={faTrashCan} />{' '}
                                        <span className="para">Delete</span>
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                              <table className="table table-striped">
                                <tbody>
                                  <tr style={{ textAlign: 'start' }}>
                                    <td
                                      style={{
                                        justifyContent: 'space-between',
                                      }}
                                      className="d-flex "
                                    >
                                      <p>
                                        <span style={{ fontWeight: 'bolder' }}>
                                          Part No :
                                        </span>
                                        {content?.partNo}
                                      </p>
                                      <p>
                                        <span style={{ fontWeight: 'bolder' }}>
                                          Manufacturer :
                                        </span>
                                        {content?.manufacturer}
                                      </p>
                                    </td>
                                  </tr>
                                  <tr style={{ textAlign: 'start' }}>
                                    <td>
                                      <span style={{ fontWeight: 'bolder' }}>
                                        Brand :
                                      </span>{' '}
                                      {content?.brand}
                                    </td>
                                  </tr>
                                  <tr style={{ textAlign: 'start' }}>
                                    <td>
                                      <span style={{ fontWeight: 'bolder' }}>
                                        Status :
                                      </span>{' '}
                                      {content?.status}
                                    </td>
                                  </tr>
                                  <tr style={{ textAlign: 'start' }}>
                                    <td>
                                      <span style={{ fontWeight: 'bolder' }}>
                                        SpecificType :
                                      </span>{' '}
                                      {content?.specificType?.label}
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  <div
                    style={{
                      position: 'sticky',
                      bottom: '0',
                      background: 'white',
                    }}
                    className="d-flex justify-content-center p-3"
                  >
                    <Pagination
                      count={totalPartPage}
                      page={partpage}
                      onChange={handlePartPageChange}
                      shape="rounded"
                      color="primary"
                    />
                  </div>
                </div>
              ) : (
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '70%',
                  }}
                >
                  No Records Found
                </div>
              )}
            </div>
          ) : (
            <div style={{ height: '100%' }}>
              <div
                style={{ top: '0', position: 'sticky', background: 'white' }}
                className=" d-flex align-items-center justify-content-between p-2"
              >
                <span>TaskCount : {taskCount}</span>
                <i
                  style={{ cursor: 'pointer' }}
                  onClick={handleRefresh}
                  className="fa-solid fa-rotate-right"
                ></i>
              </div>
              {tasks?.length !== 0 ? (
                <div>
                  {Array.isArray(tasks) &&
                    tasks?.map((content, index) => (
                      <div key={index}>
                        <div
                          style={{
                            width: '100%',
                            transition: 'height 5s in-ease-out',
                            height: 'fit-content',
                          }}
                          className={`border rounded p-3 border-primary mt-2`}
                        >
                          <table className="table table">
                            <thead>
                              <tr>
                                <th>PDFs</th>
                                <th>SpecificType</th>
                                <th>Created Time</th>
                                <th>Status</th>
                                {content?.status === 'FAILED' && (
                                  <th>Action</th>
                                )}
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td
                                  className="truncate"
                                  data-bs-placement="top"
                                  title={content?.pdfs}
                                >
                                  {content?.pdfs}
                                </td>
                                <td
                                  className="truncate"
                                  data-bs-placement="top"
                                  title={content?.SpecificType?.label}
                                >
                                  {content?.SpecificType?.label}
                                </td>
                                <td
                                  className="truncate"
                                  title={content?.createdAt}
                                >
                                  {formatCreatedAt(content?.createdAt)}
                                </td>
                                <td className="truncate">
                                  <Tag
                                    color={
                                      content.status === 'FAILED'
                                        ? 'error'
                                        : 'blue'
                                    }
                                    icon={
                                      content?.status === 'FAILED' ? (
                                        <CloseCircleOutlined />
                                      ) : (
                                        <SyncOutlined spin />
                                      )
                                    }
                                  >
                                    {content?.status}
                                  </Tag>
                                </td>
                                {content?.status === 'FAILED' && (
                                  <td>
                                    <button
                                      onClick={() => handleDeleteTask(content)}
                                      className="btn btn-outline-danger"
                                    >
                                      <FontAwesomeIcon icon={faTrashCan} />
                                    </button>
                                  </td>
                                )}
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ))}
                  <div
                    style={{
                      position: 'sticky',
                      bottom: '0',
                      background: 'white',
                    }}
                    className="d-flex justify-content-center p-3"
                  >
                    <Pagination
                      count={totalTaskPage}
                      page={taskpage}
                      onChange={handleTaskPageChange}
                      shape="rounded"
                      color="primary"
                    />
                  </div>
                </div>
              ) : (
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '70%',
                  }}
                >
                  No Records Found
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {/* Modal for displaying details */}
      <Modal
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        centered
        width={800}
        className="part-details-modal" // Apply a custom class for styling
      >
        {selectedPart && (
          <div className="part-details-container">
            {' '}
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <h3>Part Details</h3>
            </div>
            <div className="part-details-header">
              <div className="part-details-heading mt-4">
                <p>
                  <strong>Specific Type:</strong>{' '}
                  {selectedPart?.specificType?.label}
                </p>
                <p>
                  <strong>Part No:</strong> {selectedPart?.partNo}
                </p>
              </div>
            </div>
            <div className="part-details-scrollable">
              <p>
                <strong>Manufacturer: </strong>
                {selectedPart?.manufacturer}
              </p>
              <p>
                <strong>Brand: </strong>
                {selectedPart?.brand}
              </p>
              <p>
                <strong>Status: </strong>
                {selectedPart?.status}
              </p>
              {selectedPart?.result && (
                <div>
                  {JSON.parse(selectedPart?.result)?.map((attribute, index) => (
                    <p key={index}>
                      <strong>{attribute?.name} : </strong>
                      {typeof attribute?.value?.value === 'object'
                        ? Object.entries(attribute?.value.value).map(
                            ([key, val], index) => (
                              <span key={key}>
                                {val} {attribute?.value.unit}{' '}
                                {index <
                                Object.entries(attribute?.value.value).length -
                                  1
                                  ? ', '
                                  : ''}
                              </span>
                            ),
                          )
                        : attribute?.value?.value}{' '}
                      {attribute?.value?.unit}
                    </p>
                  ))}
                </div>
              )}
              {missingAttribute &&
                missingAttribute?.map((attribute, index) => (
                  <div style={{ color: 'red' }} key={index}>
                    <p>
                      <strong>{attribute?.name} : </strong>
                    </p>
                  </div>
                ))}
            </div>
          </div>
        )}
      </Modal>
      <Modal
        open={openRetryModal}
        cancelText={'Cancel'}
        onCancel={handleRetryClose}
        centered
        footer={[
          <button
            onClick={handleRetryClose}
            className="btn btn-outline-secondary me-3"
            key={'cancel'}
          >
            Cancel
          </button>,
          <button
            onClick={handleRetry}
            disabled={missingAttribute?.length === 0}
            style={{
              cursor: `${missingAttribute?.length === 0 ? 'not-allowed' : 'pointer'}`,
            }}
            className="btn btn-outline-primary"
            key={'retry'}
          >
            Retry
          </button>,
        ]}
        width={800}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: '20px',
          }}
        >
          <h3>Retry Missing Attributes</h3>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span className="fs-5">
            <strong>Part No : </strong>
            {retryPart?.partNo}
          </span>
          <span className="fs-5">
            <strong>Specific Type : </strong>
            {retryPart?.specificType?.label}
          </span>
        </div>
        <span
          className="mt-4 fs-5"
          style={{
            display: 'flex',
            justifyContent: 'start',
          }}
        >
          {missingAttribute ? (
            <strong>Missing Attributes :</strong>
          ) : (
            <strong>No Missing Attribute Found</strong>
          )}
        </span>
        <div
          style={{
            maxHeight: '350px',
            overflowY: 'auto',
            padding: '20px',
            margin: '0 20px 20px 20px',
          }}
        >
          {missingAttribute &&
            missingAttribute?.map((attribute, index) => (
              <p className="fs-5" key={index}>
                {attribute?.name}
              </p>
            ))}
        </div>
      </Modal>
    </div>
  );
}

export default Display;
