import React, { useState } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import './Nav.css';
import logo from './new.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPowerOff } from '@fortawesome/free-solid-svg-icons';
import { Dropdown } from 'antd';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

const Navbar = () => {
  const location = useLocation();
  const [activeButton, setActiveButton] = useState(location.pathname);

  const handleLogout = () => {
    localStorage.removeItem('token');
    window.location.reload();
  };

  const items = [
    {
      key: '1',
      label: (
        <Link onClick={handleLogout} style={{ textDecoration: 'none' }}>
          {' '}
          <FontAwesomeIcon icon={faSignOutAlt} /> Logout
        </Link>
      ),
    },
  ];

  const handleButtonClick = (path) => {
    setActiveButton(path);
  };

  return (
    <div className="w-100">
      <nav className="navbar navbar-expand-lg bg-body w-100">
        <div className="d-flex ps-3 pe-3 justify-content-between w-100">
          <Link to={'/upload'} className="logo-link">
            <span>
              <img style={{width:'25px'}}  src={logo} alt="Home" className="logo" />
            </span>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
        </div>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mx-auto mb-2 mb-lg-0 gap-3">
            <li className={`nav-item ${activeButton === '/upload' ? 'active' : ''}`}>
              <Link
                to={'/upload'}
                className="nav-link"
                onClick={() => handleButtonClick('/upload')}
              >
                Home
              </Link>
            </li>
            <li className={`nav-item ${activeButton === '/category' ? 'active' : ''}`}>
              <Link
                to={'/category'}
                className="nav-link"
                onClick={() => handleButtonClick('/category')}
              >
                Category
              </Link>
            </li>
            <li className={`nav-item ${activeButton === '/subcategory' ? 'active' : ''}`}>
              <Link
                to={'/subcategory'}
                className="nav-link"
                onClick={() => handleButtonClick('/subcategory')}
              >
                SubCategory
              </Link>
            </li>
            <li className={`nav-item ${activeButton === '/specifictype' ? 'active' : ''}`}>
              <Link
                to={'/specifictype'}
                className="nav-link"
                onClick={() => handleButtonClick('/specifictype')}
              >
                SpecificType
              </Link>
            </li>
            <li className={`nav-item ${activeButton === '/attributename' ? 'active' : ''}`}>
              <Link
                to={'/attributename'}
                className="nav-link"
                onClick={() => handleButtonClick('/attributename')}
              >
                Attributes
              </Link>
            </li>
            <li className={`nav-item ${activeButton === '/product' ? 'active' : ''}`}>
              <Link
                to={'/product'}
                className="nav-link"
                onClick={() => handleButtonClick('/product')}
              >
                Product
              </Link>
            </li>
            <li className={`nav-item`}>
              <Link style={{ textDecoration: 'none', color: 'gray' }} className="nav-link">
                <Dropdown menu={{ items }} placement="bottomLeft" arrow>
                  <FontAwesomeIcon icon={faPowerOff} />
                </Dropdown>
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
