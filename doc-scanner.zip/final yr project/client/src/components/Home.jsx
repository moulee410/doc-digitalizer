import React, { useState } from 'react';
import Display from './Display';
import Upload from './Upload';

function Home() {
  const [refresh, setRefresh] = useState(false);
  const [showTask, setShowTask] = useState(false);

  return (
    <div>
      <div style={{}} className="group ">
      <div className="lol">
          <Display
            showTask={showTask}
            setShowTask={setShowTask}
            refresh={refresh}
            setRefresh={setRefresh}
          />
        </div>
      <div className="loll">
          <Upload
            showTask={showTask}
            setShowTask={setShowTask}
            refresh={refresh}
            setRefresh={setRefresh}
          />
        </div>
    
       
      </div>
    </div>
  );
}

export default Home;
