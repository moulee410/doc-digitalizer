import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react';

import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { message } from 'antd';
import Swal from 'sweetalert2';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faXmark } from '@fortawesome/free-solid-svg-icons';

const Upload = ({ refresh, setRefresh, showTask, setShowTask }) => {
  const [pdf, setPdf] = useState([]);
  const [showDataSheet, setShowDataSheet] = useState(false);
  const [specificTypeId, setSpecificTypeId] = useState('');
  const [disabled, setDisabled] = useState(false);
  const [specificType, setSpecificType] = useState([]);
  const [files, setFiles] = useState([]);
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [extractedText, setExtractedText] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processing, setProcessing] = useState(false);

  // Function to handle file selection
  const handleFileChanged = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  // Function to handle file upload
  const handleUpload = async () => {
    if (!selectedFile) {
      alert('Please select a file.');
      return;
    }

 


    setProcessing(true); 

    const formData = new FormData();
    formData.append('image', selectedFile);

    try {
      const response = await axios.post(
        'http://localhost:3005/api/process-image',
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        },
      );

      setExtractedText(response.data.text);
      console.log(response.data);
      setUploadProgress(0);
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('An error occurred while processing the image.');
      setUploadProgress(0);
    } finally {
      setProcessing(false); 
    }
  };

  const handleRemoveFile = (index) => {
    const newFiles = [...files];
    newFiles.splice(index, 1);
    setFiles(newFiles);
    const newPdf = [...pdf];
    newPdf.splice(index, 1);
    setPdf(newPdf);
  };

  useEffect(() => {
    axios
      .get(
        process.env.REACT_APP_PORTURL + '/specifictypes/onlywithattributenames',
      )
      .then((response) => {
        setSpecificType(response.data);
      })
      .catch(() => {
        message.error('Server Error');
      });
  }, []);

  const handleFileChange = (event) => {
    if (files.length + event.target.files.length > 10) {
      message.error("You can't upload more than 10 files");
      return;
    }
    const fileList = event.target.files;
    const fileNames = Array.from(fileList).map((file) => file.name);
    setFiles([...files, ...fileNames]);
    setPdf([...pdf, fileList]);
  };

  const handleSubmitFile = async (e) => {
    e.preventDefault();
    if (pdf.length === 0) {
      return;
    }
    const formdata = new FormData();
    pdf.forEach((fileList) => {
      Array.from(fileList).forEach((file) => {
        formdata.append('pdf', file);
      });
    });
    try {
      axios
        .post(process.env.REACT_APP_PORTURL + '/finder/uploadmany', formdata, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        })
        .then((res) => {
          setRefresh(!refresh);
          console.log(res);
        })
        .catch((err) => message.error(err.message));
      let timerInterval;
      Swal.fire({
        icon: 'success',
        title: 'Task Created Successfully',
        confirmButtonColor: '#75be75',
        timer: 1500,
        willClose: () => {
          clearInterval(timerInterval);
        },
      });
      setFiles([]);
      setPdf([]);
      setSpecificTypeId('');
      setShowTask(true);
      fileInputRef.current.value = '';
      setDisabled(false);
      setTimeout(() => {
        setRefresh(!refresh);
      }, 1000);
    } catch (err) {
      message.error(err);
    }
  };

  const handleSubmitFileWithSpecificId = async (e) => {
    e.preventDefault();
    if (pdf.length === 0) {
      console.log('NO PDF');
      return;
    }
    const formData = new FormData();
    pdf.forEach((fileList) => {
      Array.from(fileList).forEach((file) => {
        formData.append('pdf', file);
      });
    });
    formData.append('specifictypeid', specificTypeId);

    try {
      setDisabled(true);

      axios
        .post(
          process.env.REACT_APP_PORTURL + '/finder/uploadmanywithtype',
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          },
        )
        .then((res) => {
          setRefresh(!refresh);
          console.log(res);
        })
        .catch((err) => {
          message.error(err.message);
          console.log(err);
        });

      let timerInterval;
      Swal.fire({
        icon: 'success',
        title: 'Task Created Successfully',
        confirmButtonColor: '#75be75',
        timer: 1500,
        willClose: () => {
          clearInterval(timerInterval);
        },
      });
      setTimeout(() => {
        setRefresh(!refresh);
      }, 1000);
      setSpecificTypeId('');
      setFiles([]);
      setPdf([]);
      setShowTask(true);
      fileInputRef.current.value = '';
      setDisabled(false);
    } catch (err) {
      console.log(err);
      message.error(err);
    }
  };
  const handleAutocompleteChange = (event, value) => {
    setSpecificTypeId(value?.id);
  };
  const handlesubmitimgdata = () => {
    axios.post('http://localhost:3001/api/img',extractedText)
      .then((res) => {
        console.log(res.data); 
      })
      .catch((err) => {
        console.error('Error:', err);
      });
  };
  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <div
        style={{
          width: '100%',
          height: '100%',
          backgroundColor: 'white',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'start',
          padding: '20px',
          textAlign: 'center',
        }}
        className="response rounded-2 p-3"
      >
        <nav className="mini-nav border mb-4">
          <ul>
            <li
              className={!showDataSheet ? 'active' : ''}
              onClick={() => setShowDataSheet(false)}
            >
              SpecificType
            </li>
            <li
              className={showDataSheet ? 'active' : ''}
              onClick={() => setShowDataSheet(true)}
            >
              DataSheet
            </li>
          </ul>
        </nav>
        {showDataSheet ? (
          <>
            <p
              style={{
                color: '#11009E',
                fontWeight: 'bold',
                marginBottom: '20px',
                fontSize: '25px',
              }}
            >
              Please upload your Image
            </p>
            <div className="file-upload" style={{ marginBottom: '20px' }}>
              <input
                type="file"
                id="fileInput"
                className="file-input"
                onChange={handleFileChanged}
                multiple
                style={{ display: 'none' }}
              />
              <label htmlFor="fileInput" className="file-label">
                <i className="fa-solid fa-cloud-arrow-up"></i>
                <span className="drop-message" style={{ marginLeft: '10px' }}>
                  Drop your files here
                </span>
              </label>
              {files.length > 0 && (
                <ul
                  style={{
                    listStyle: 'none',
                    marginTop: '20px',
                    textAlign: 'left',
                  }}
                >
                  {files.map((fileName, index) => (
                    <li
                      key={index}
                      style={{
                        marginBottom: '10px',
                        display: 'flex',
                        justifyContent: 'space-between',
                      }}
                    >
                      <div>
                        <i
                          style={{
                            fontSize: '1.1rem',
                            color: 'green',
                            marginRight: '10px',
                          }}
                          className="fa-solid fa-file-pdf"
                        ></i>
                        <i> {fileName} </i>
                      </div>
                      <FontAwesomeIcon
                        onClick={() => handleRemoveFile(index)}
                        icon={faXmark}
                      />
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <button
              onClick={handleUpload}
              style={{
                backgroundColor: '#0088ff',
                color: 'white',
                border: 'none',
                padding: '10px 20px',
                borderRadius: '5px',
                cursor:
                  files.length === 0 || disabled ? 'not-allowed' : 'pointer',
                opacity: files.length === 0 || disabled ? 0.5 : 1,
              }}
            >
              <i className="fa-solid fa-upload"></i>
              <span style={{ marginLeft: '10px' }}>Create Task</span>
            </button>

            {processing && (
              <div className="">
                <span>Processing Image...</span>
                <div
                  style={{ color: 'green' }}
                  className="spinner-border"
                  role="status"
                >
                  <span className="visually-hidden">Processing...</span>
                </div>
              </div>
            )}
            {extractedText && (
              <div className="mt-4">
                <strong>Extracted Text:</strong>
                <p>{extractedText}</p>
              </div>
            )} 
            <button onClick={handlesubmitimgdata}>Click</button>

          </>
        ) : (
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              textAlign: 'center',
            }}
          >
            <p
              style={{
                color: '#11009E',
                fontWeight: 'bold',
                marginBottom: '20px',
                fontSize: '25px',
              }}
            >
              Please upload your datasheet
            </p>
            <Autocomplete
              disablePortal
              id="combo-box-demo"
              options={specificType || []}
              className="w-100"
              clearIcon={null}
              value={
                specificType?.find((item) => item?.id === specificTypeId) ||
                null
              }
              onChange={handleAutocompleteChange}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Specific Type"
                  InputLabelProps={
                    {
                      // Change the color to green
                    }
                  }
                />
              )}
              sx={{
                '& .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline':
                  {
                    borderColor: '#FFA114',
                  },
                '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline':
                  {
                    borderColor: '#FFA114',
                  },
              }}
            />

            <div className="file-upload mt-3" style={{ marginBottom: '20px' }}>
              <input
                type="file"
                id="fileInput"
                ref={fileInputRef}
                className="file-input"
                onChange={handleFileChange}
                multiple
                style={{ display: 'none' }}
              />
              <label htmlFor="fileInput" className="file-label">
                <i className="fa-solid fa-cloud-arrow-up"></i>
                <span className="drop-message" style={{ marginLeft: '10px' }}>
                  Drop your files here
                </span>
              </label>
              {files.length > 0 && (
                <ul
                  style={{
                    listStyle: 'none',
                    marginTop: '20px',
                    textAlign: 'left',
                  }}
                >
                  {files.map((fileName, index) => (
                    <li
                      key={index}
                      style={{
                        marginBottom: '10px',
                        display: 'flex',
                        justifyContent: 'space-between',
                      }}
                    >
                      <div>
                        <i
                          style={{
                            fontSize: '1.1rem',
                            color: 'green',
                            marginRight: '10px',
                          }}
                          className="fa-solid fa-file-pdf"
                        ></i>
                        <i> {fileName} </i>
                      </div>
                      <FontAwesomeIcon
                        onClick={() => handleRemoveFile(index)}
                        icon={faXmark}
                      />
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <button
              onClick={handleSubmitFileWithSpecificId}
              disabled={files.length === 0 || disabled}
              style={{
                backgroundColor: '#0088ff',
                color: 'white',
                border: 'none',
                padding: '10px 20px',
                borderRadius: '5px',
                cursor:
                  files.length === 0 || disabled ? 'not-allowed' : 'pointer',
                opacity: files.length === 0 || disabled ? 0.5 : 1,
              }}
            >
              <i className="fa-solid fa-upload"></i>
              <span style={{ marginLeft: '10px' }}>Create Task</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Upload;
