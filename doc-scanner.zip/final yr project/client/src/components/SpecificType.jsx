import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import More from './More.png';
import './overflow.css';
import Pagination from '@mui/material/Pagination';
import { message } from 'antd';

function SpecificType() {
  const [data, setData] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [description, setDescription] = useState('');
  const [label, setLabel] = useState('');
  const [subCategoryId, setSubCategoryId] = useState('');
  const [selectedData, setSelectedData] = useState(null);
  const [refresh, setRefresh] = useState(false);
  const [editData, setEditData] = useState(null);
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);

  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + `/specifictypes?page=${page}`)
      .then((response) => {
        setData(response.data.specificTypes);
        setTotalPage(response.data.totalPage);
      })
      .catch(() => {
        console.log('error in specific types');
        message.error('Server Error');
      });
  }, [refresh, page]);

  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/subcategories')
      .then((response) => {
        setSubcategories(response.data.subCategories);
      })
      .catch(() => {
        console.log('error in subcategories');
        message.error('Server Error');
      });
  }, []);

  const handleClose = () => {
    setShowModal(false);
    resetForm();
  };

  const resetForm = () => {
    setDescription('');
    setLabel('');
    setSubCategoryId('');
    setEditData(null);
    setSelectedData(null);
  };

  const handleShow = () => {
    setShowModal(true);
    resetForm();
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleLabelChange = (e) => {
    setLabel(e.target.value);
  };

  const handleSubcategoryIdChange = (e) => {
    setSubCategoryId(e.target.value);
  };

  const handleAddSpecificType = (e) => {
    e.preventDefault();
    let payload = {
      label: label,
      description: description,
      subCategoryId: subCategoryId,
    };
    axios
      .post(process.env.REACT_APP_PORTURL + '/specifictypes', payload)
      .then(() => {
        console.log('Specific type data sent');
        setRefresh(!refresh);
        message.success('Data Added Successfully');
      })
      .catch((err) => {
        console.log(err);
        message.error('Server Error');
      });

    handleClose();
  };

  const handleEdit = (data) => {
    setEditData(data);

    setDescription(data.description);
    setLabel(data.label);
    setSubCategoryId(data.subCategoryId);
    setShowModal(true);
  };

  const handleView = (data) => {
    setSelectedData(data);
    setShowModal(true);
  };

  const handleDelete = (data) => {
    axios
      .delete(process.env.REACT_APP_PORTURL + '/specifictypes/' + data.id)
      .then((res) => {
        console.log('Specific type deleted successfully');
        message.success('Data  Deleted successfully');
        setRefresh(!refresh);
      })
      .catch((err) => {
        console.log(err);
        message.error('Server Error');
      });
  };

  const handleSaveEdit = () => {
    let val = {};
    if (editData.description !== description) {
      val = { ...val, description };
    }
    if (editData.label !== label) {
      val = { ...val, label };
    }
    if (editData.subCategoryId !== subCategoryId) {
      val = { ...val, subCategoryId };
    }
    axios
      .put(process.env.REACT_APP_PORTURL + '/specifictypes/' + editData.id, val)
      .then(() => {
        console.log('Specific type data updated');
        setRefresh(!refresh);
      })
      .catch(() => {
        console.log('Error updating specific type data');
        message.error('Server Error');
      });

    handleClose();
  };

  const getSubcategoryNameById = (subcategoryId) => {
    const subcategory = subcategories.find(
      (subcategory) => subcategory.id === subcategoryId,
    );
    return subcategory ? subcategory.label : '';
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  return (
    <div className="pb-4">
      <div
        style={{
          height: '80vh',
          position: 'relative',
          backgroundColor: 'white',
          margin: '0 3%',
          padding: '10px',
        }}
        className="rounded-3 mt-3"
      >
        <div className="container"></div>
        <div className="box p-1 ">
          <div
            style={{
              alignItems: 'center',
              width: '100%',
              justifyContent: 'space-between',
              paddingRight: '5%',
            }}
            className="d-flex gap-2 "
          >
            <div>
              <h4 style={{ fontWeight: 'bold' }}>Specific type</h4>
            </div>

            <button onClick={handleShow} className="btn btn-primary">
              Create
            </button>
          </div>
          <hr></hr>
          <div
            style={{
              position: 'relative',
              height: '67vh',
              overflowY: 'scroll',
            }}
            className="table mt-3 "
          >
            <table className="table">
              <thead
                style={{
                  position: 'sticky',
                  top: 0,
                  backgroundColor: 'hsl(202, 100%, 77%)',
                }}
              >
                <tr>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>Name</th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    Sub Category Name
                  </th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>Description</th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}></th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(data) &&
                  data.map((data, index) => (
                    <tr key={index}>
                      <td
                        className="truncate"
                        data-bs-placement="top"
                        title="Tooltip on top"
                      >
                        {data.label}
                      </td>
                      <td className="truncate">
                        {' '}
                        {getSubcategoryNameById(data.subCategoryId)}
                      </td>
                      <td className="truncate">{data.description}</td>

                      <td>
                        <div style={{ textAlign: 'center' }}>
                          <img
                            className="dropdown-toggle"
                            type="button"
                            id="dropdownMenuButton1"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            src={More}
                            alt=""
                          />
                          <ul
                            className="dropdown-menu p-2  rounded"
                            aria-labelledby="dropdownMenuButton1"
                          >
                            <li className=" rounded-1 drophover">
                              {' '}
                              <button
                                style={{
                                  background: 'transparent',
                                  border: 'none',
                                  color: '',
                                }}
                                onClick={() => handleView(data)}
                              >
                                View
                              </button>
                            </li>
                            <li className=" rounded-1 drophover text-success">
                              <button
                                style={{
                                  background: 'transparent',
                                  border: 'none',
                                  color: 'green',
                                }}
                                onClick={() => handleEdit(data)}
                              >
                                Update
                              </button>
                            </li>
                            <li className=" rounded-1 drophover text-danger">
                              <button
                                style={{
                                  background: 'transparent',
                                  border: 'none',
                                  color: 'red',
                                }}
                                onClick={() => handleDelete(data)}
                              >
                                Delete
                              </button>
                            </li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  ))}

                {/* Add more table rows as needed */}
              </tbody>
            </table>
            <Modal show={showModal} onHide={handleClose} centered>
              <Modal.Header closeButton>
                <Modal.Title>
                  {selectedData
                    ? 'Specific Type Details'
                    : editData
                      ? 'Edit Specific Type'
                      : 'Add Specific Type'}
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                {selectedData ? (
                  <div>
                    <p>
                      <strong>Name:</strong> {selectedData.label}
                    </p>
                    <p>
                      <strong>Description:</strong> {selectedData.description}
                    </p>
                    <p>
                      <strong>Subcategory ID:</strong>{' '}
                      {getSubcategoryNameById(selectedData.subCategoryId)}
                    </p>
                  </div>
                ) : (
                  <Form>
                    <Form.Group controlId="formLabel">
                      <Form.Label>Name</Form.Label>
                      <Form.Control
                        type="text"
                        value={label}
                        onChange={handleLabelChange}
                      />
                    </Form.Group>
                    <Form.Group controlId="formDescription">
                      <Form.Label>Description</Form.Label>
                      <Form.Control
                        as="textarea"
                        rows={3}
                        value={description}
                        onChange={handleDescriptionChange}
                      />
                    </Form.Group>
                    <Form.Group controlId="formSubcategoryId">
                      <Form.Label>Subcategory</Form.Label>
                      <Form.Control
                        as="select"
                        value={subCategoryId}
                        onChange={handleSubcategoryIdChange}
                      >
                        <option value="">Select Subcategory</option>
                        {Array.isArray(subcategories) &&
                          subcategories.map((subcategory) => (
                            <option key={subcategory.id} value={subcategory.id}>
                              {subcategory.label}
                            </option>
                          ))}
                      </Form.Control>
                    </Form.Group>
                  </Form>
                )}
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  {' '}
                  Discard{' '}
                </Button>
                {selectedData ? null : editData ? (
                  <Button variant="primary" onClick={handleSaveEdit}>
                    {' '}
                    Update Secifictypes{' '}
                  </Button>
                ) : (
                  <Button variant="primary" onClick={handleAddSpecificType}>
                    {' '}
                    Add Specifictypes{' '}
                  </Button>
                )}
              </Modal.Footer>
            </Modal>
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-center mt-2 ">
        <Pagination
          count={totalPage}
          page={page}
          onChange={handlePageChange}
          shape="rounded"
          color="primary"
        />
      </div>
    </div>
  );
}

export default SpecificType;
