import Autocomplete from '@mui/material/Autocomplete';
import Pagination from '@mui/material/Pagination';
import TextField from '@mui/material/TextField';
import { message } from 'antd';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import './overflow.css';
import { faTrashCan, faFileExcel } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

function Product() {
  const [data, setData] = useState([]);
  const [refresh, setRefresh] = useState(false);
  const [specificTypeId, setSpecificTypeId] = useState('');
  const [specificType, setSpecificType] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);
  const [attributes, setAttributes] = useState([]);
  useEffect(() => {
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/products', {
        params: {
          page: page,
          specificTypeId,
        },
      })
      .then((response) => {
        setData(response.data.products);
        setTotalPage(response.data.totalPage);
      })
      .catch((err) => {
        message.error('Server Error');
        console.log(err);
      });
  }, [refresh, page, specificTypeId]);

  useEffect(() => {
    axios
      .get(process.env.REACT_APP_PORTURL + '/specifictypes')
      .then((response) => {
        setSpecificType(response.data.specificTypes);
      })
      .catch(() => {
        message.error('Server Error');
      });
  }, []);

  useEffect(() => {
    if (specificTypeId) {
      axios
        .get(process.env.REACT_APP_PORTURL + '/attributenames', {
          params: { specificTypeId },
        })
        .then((response) => {
          setAttributes(response.data.attributeNames);
        })
        .catch(() => {
          message.error('Server Error');
        });
    }
  }, [specificTypeId]);

  const handleDelete = (data) => {
    console.log(data);
    axios
      .delete(process.env.REACT_APP_PORTURL + '/products/' + data.id)
      .then(() => {
        setRefresh(!refresh);
        message.success('Data Deleted Successfully');
      })
      .catch((err) => {
        console.log(err);
        message.error('Server Error');
      });
  };
  const handlePageChange = (event, value) => {
    setPage(value);
  };

  const handleAutocompleteChange = (event, value) => {
    if (value) {
      setSpecificTypeId(value.id);
      setRefresh(!refresh);
    } else {
      setSpecificTypeId('');
      setRefresh(!refresh);
    }
  };
  const handleExport = () => {
    if (!specificTypeId) {
      message.error('Please select a specific type before exporting.');
      return;
    }

    axios
      .post(process.env.REACT_APP_PORTURL + '/products/excel', {
        specificTypeId,
      })
      .then((response) => {
        const fileName = response.data;
        const downloadURL = `${process.env.REACT_APP_PORTURL.replace(/\/api$/, '')}/downloads/${fileName}`;

        window.open(downloadURL, '_blank');
      })
      .catch((err) => {
        console.error('Export error:', err);
        message.error('Error exporting data.');
      });
  };

  return (
    <div className="pb-4">
      <div
        style={{
          height: '80vh',
          position: 'relative',
          backgroundColor: 'white',
          margin: '0 3%',
          padding: '10px',
        }}
        className="rounded-3 mt-3"
      >
        <div className="container"></div>
        <div className="box p-1 ">
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
            className={screenWidth < 768 ? 'mb-3 gap-2' : 'mb-3'}
          >
            <h4 style={{ fontWeight: 'bold' }}>Product</h4>
            <div
              className={
                screenWidth < 768 ? 'd-flex gap-2 w-100' : 'd-flex gap-2 w-25'
              }
            >
              <Autocomplete
                disablePortal
                id="combo-box-demo"
                options={specificType || []}
                className={screenWidth < 992 ? 'w-100' : 'w-75'}
                onChange={handleAutocompleteChange}
                clearIcon={null}
                renderInput={(params) => (
                  <TextField {...params} label="Select Specific Type" />
                )}
                sx={{
                  '& .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline':
                    {
                      borderColor: 'blue',
                    },
                  '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline':
                    {
                      borderColor: 'blue',
                    },
                }}
              />{' '}
              <button className="btn btn-primary w-50" onClick={handleExport}>
                <FontAwesomeIcon icon={faFileExcel} /> <span>Export</span>
              </button>
            </div>
          </div>

          <hr></hr>
          <div
            style={{
              position: 'relative',
              height: '63vh',
              overflowY: 'scroll',
            }}
            className="mt-3 "
          >
            <table className="table">
              <thead
                style={{
                  position: 'sticky',
                  top: 0,
                  backgroundColor: 'hsl(202, 100%, 77%)',
                }}
              >
                <tr>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px', textAlign: 'center' }}>
                      Action
                    </div>
                  </th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px' }}>Part No</div>
                  </th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px' }}>Manufacturer</div>
                  </th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px' }}>Description</div>
                  </th>
                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px' }}>Specific Type</div>
                  </th>

                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px' }}>Category</div>
                  </th>

                  <th style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                    <div style={{ width: '200px' }}>SubCategory</div>
                  </th>

                  {attributes?.map((m, index) => (
                    <th key={index} style={{ backgroundColor: 'hsl(202, 100%, 77%)' }}>
                      <div style={{ width: '200px' }}>{m?.label}</div>
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody>
                {Array.isArray(data) &&
                  data.map((item, index) => (
                    <tr key={index}>
                      <td style={{ textAlign: 'center' }}>
                        <FontAwesomeIcon
                          icon={faTrashCan}
                          className="btn text-danger"
                          onClick={() => handleDelete(item)}
                        />
                      </td>
                      <td className="">{item?.partNo}</td>
                      <td className="">{item?.manufacturer}</td>
                      <td className="">{item?.description}</td>
                      <td className="">{item?.specificType?.label}</td>
                      <td className=""> {item?.category?.label}</td>
                      <td className="">{item?.subCategory?.label}</td>
                      {attributes?.map((attribute, index) => (
                        <td key={index}>
                          {item?.ProductSpecs?.find(
                            (spec) => spec.attributeNameId === attribute.id,
                          )?.value || '-'}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="d-flex justify-content-center mt-2 ">
        <Pagination
          count={totalPage}
          page={page}
          onChange={handlePageChange}
          shape="rounded"
          color="primary"
        />
      </div>
    </div>
  );
}

export default Product;
