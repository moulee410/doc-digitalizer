import React from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import './attribute.css';


function AddModal({
  showModal,
  handleClose,
  handleAddAttributeName,
  specificTypeId,
  handleSpecificTypeIdChange,
  attributenames,
  additionalFields,
  setAdditionalFields,
}) {
  const handleAddField = () => {
    setAdditionalFields([...additionalFields, { label: '', description: '' }]);
  };

  const handleNameChange = (index, value) => {
    const updatedFields = [...additionalFields];
    updatedFields[index].label = value;
    setAdditionalFields(updatedFields);
  };

  const handleAdditionalDescriptionChange = (index, value) => {
    const updatedFields = [...additionalFields];
    updatedFields[index].description = value;
    setAdditionalFields(updatedFields);
  };

  const handleCloseModal = () => {
    setAdditionalFields([{ label: '', description: '' }]);
    handleClose();
  };
  return (
    <Modal show={showModal} onHide={handleCloseModal} size="xl" centered>
      <Modal.Header closeButton>
        <Modal.Title>Add Attribute Name</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="offset-8" controlId="formSpecificTypeId">
            <Form.Label column>Specific Type:</Form.Label>
            <Form.Control
              as="select"
              value={specificTypeId}
              onChange={handleSpecificTypeIdChange}
            >
              <option value="">Select Specific Type</option>
              {attributenames.map((specificType) => (
                <option key={specificType.id} value={specificType.id}>
                  {specificType.label}
                </option>
              ))}
            </Form.Control>
          </Form.Group>
          <div
            className="overflow-y-auto overflow-x-hidden"
            style={{ maxHeight: '400px' }}
          >
            <div className="border mt-4 rounded bg-light">
              {additionalFields.map((field, index) => (
                <div
                  key={index}
                  className="d-flex flex-column flex-md-row justify-content-start mt-2 p-2"
                >
                  <Form.Group
                    className="col-12 col-md-5 d-flex p-2 justify-content-between"
                    controlId={`additionalName${index}`}
                  >
                    <Form.Label className="d-block" column sm={3}>
                      Name
                    </Form.Label>
                    <Form.Control
                      className="d-block"
                      type="text"
                      value={field.label}
                      onChange={(e) => handleNameChange(index, e.target.value)}
                    />
                  </Form.Group>
                  <Form.Group
                    className="col-12 col-md-6 d-flex p-2"
                    controlId={`additionalDescription${index}`}
                  >
                    <Form.Label className="d-block" column sm={3}>
                      Description
                    </Form.Label>
                    <Form.Control
                      className="d-block"
                      type="text"
                      value={field.description}
                      onChange={(e) =>
                        handleAdditionalDescriptionChange(index, e.target.value)
                      }
                    />
                  </Form.Group>
                  {index === additionalFields.length - 1 && (
                    <Form.Group
                      className="col-12 col-md-1 d-flex p-2"
                      controlId="formDescription"
                      id="btn"
                    >
                      <Button variant="secondary" onClick={handleAddField}>
                        +
                      </Button>
                    </Form.Group>
                  )}
                </div>
              ))}
            </div>
          </div>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleCloseModal}>
          Discard
        </Button>
        <Button variant="primary" onClick={handleAddAttributeName}>
          Add
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default AddModal;
