import { useEffect, useState } from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Category from './components/Category';
import SubCategory from './components/SubCategory';
import Product from './components/Product';
import SpecificType from './components/SpecificType';
import Attributenames from './components/Attribute';
import PageErr404 from './components/PageErr404';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    console.log(process.env.REACT_APP_PORTURL);
    if (token) {
      setLoggedIn(true);
    }
    setLoading(false); // Update loading state after checking token
  }, []);

  // If loading, display a loading indicator or skeleton screen
  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="App">
      {!loggedIn ? (
        <Routes>
          <Route path="/login" element={<Login setLoggedIn={setLoggedIn} />} />
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      ) : (
        <div
          className=""
          style={{
            backgroundColor: '',
            height: '100%',
          }}
        >
          <Navbar /> 
          <Routes>
            <Route path="/" element={<Navigate to="/upload" />} />
            <Route path="/upload" element={<Home />} />
            <Route path="/category" element={<Category />} />
            <Route path="/subcategory" element={<SubCategory />} />
            <Route path="/product" element={<Product />} />
            <Route path="/specifictype" element={<SpecificType />} />
            <Route path="/attributename" element={<Attributenames />}></Route>
            <Route path="*" element={<PageErr404 />} />
          </Routes>
        </div>
      )}
    </div>
  );
}

export default App;
