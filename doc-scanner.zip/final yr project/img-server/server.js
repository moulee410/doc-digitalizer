const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const port = 3005;

// Enable CORS for all origins (replace '*' with specific origin for production)
app.use(cors());

// Configure multer for file upload
const upload = multer({ dest: 'uploads/' });

// Initialize Google Generative AI client with your API key
const genAI = new GoogleGenerativeAI('AIzaSyDAWbxUfm_5XeGVj2GtIGXqsTSbVkUbbYQ');

// Function to prepare image data for Generative AI
function fileToGenerativePart(path, mimeType) {
  const data = fs.readFileSync(path, { encoding: 'base64' });
  return {
    inlineData: {
      data,
      mimeType,
    },
  };
}

// Route for uploading an image and processing with Generative AI
app.post('/api/process-image', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).send('No file uploaded.');
    }

    const imagePath = req.file.path;
    const imageMimeType = req.file.mimetype;

    // Prepare image data for Generative AI
    const imagePart = fileToGenerativePart(imagePath, imageMimeType);

    // Create Generative AI model instance
    const model = genAI.getGenerativeModel({ model: 'gemini-pro-vision' });

    // Define prompt and image parts
    const prompt = 'take telephone number and name from these image';
    const imageParts = [imagePart];

    // Generate content using Generative AI
    const result = await model.generateContent([prompt, ...imageParts]);
    const response = await result.response;
    const extractedText = await response.text();

    // Respond with extracted text
    res.status(200).json({ text: extractedText });
    console.log(extractedText);

    // Clean up: delete uploaded image file after processing
    fs.unlinkSync(imagePath);
  } catch (error) {
    console.error('Error processing image:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the Express server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
