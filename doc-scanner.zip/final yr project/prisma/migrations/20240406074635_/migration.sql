-- AlterTable
ALTER TABLE "attributenames" ADD COLUMN     "description" TEXT;
