-- CreateTable
CREATE TABLE "tasks" (
    "id" TEXT NOT NULL,
    "taskName" TEXT NOT NULL,
    "status" TEXT NOT NULL,

    CONSTRAINT "tasks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "taskresults" (
    "id" TEXT NOT NULL,
    "taskContent" TEXT NOT NULL,
    "taskResult" TEXT NOT NULL,
    "taskId" TEXT NOT NULL,

    CONSTRAINT "taskresults_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "taskresults" ADD CONSTRAINT "taskresults_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "tasks"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
