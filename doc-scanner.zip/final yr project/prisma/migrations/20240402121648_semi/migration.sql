-- CreateTable
CREATE TABLE "products" (
    "id" TEXT NOT NULL,
    "partNo" TEXT,
    "description" TEXT,
    "manufacturer" TEXT,
    "specificTypeId" TEXT NOT NULL,

    CONSTRAINT "products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "productspecs" (
    "id" TEXT NOT NULL,
    "attributeNameId" TEXT NOT NULL,
    "value" TEXT,

    CONSTRAINT "productspecs_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_specificTypeId_fkey" FOREIGN KEY ("specificTypeId") REFERENCES "specifictypes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "productspecs" ADD CONSTRAINT "productspecs_attributeNameId_fkey" FOREIGN KEY ("attributeNameId") REFERENCES "attributenames"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
