-- CreateTable
CREATE TABLE "attributenames" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "specificTypeId" TEXT NOT NULL,

    CONSTRAINT "attributenames_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "attributenames" ADD CONSTRAINT "attributenames_specificTypeId_fkey" FOREIGN KEY ("specificTypeId") REFERENCES "specifictypes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
