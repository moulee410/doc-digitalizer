/*
  Warnings:

  - You are about to drop the column `taskName` on the `tasks` table. All the data in the column will be lost.
  - You are about to drop the `taskresults` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `updatedAt` to the `tasks` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "PartParsingStatus" AS ENUM ('INPROGRESS', 'SUCCESS', 'FAILED');

-- DropForeignKey
ALTER TABLE "taskresults" DROP CONSTRAINT "taskresults_taskId_fkey";

-- AlterTable
ALTER TABLE "tasks" DROP COLUMN "taskName",
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "pdfs" TEXT,
ADD COLUMN     "specificTypeId" TEXT,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;

-- DropTable
DROP TABLE "taskresults";

-- CreateTable
CREATE TABLE "parts" (
    "id" TEXT NOT NULL,
    "partNo" TEXT NOT NULL,
    "manufacturer" TEXT NOT NULL,
    "brand" TEXT NOT NULL,
    "datasheet" TEXT,
    "result" TEXT,
    "status" "PartParsingStatus" NOT NULL DEFAULT 'INPROGRESS',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "specificTypeId" TEXT NOT NULL,

    CONSTRAINT "parts_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "parts_partNo_key" ON "parts"("partNo");

-- AddForeignKey
ALTER TABLE "parts" ADD CONSTRAINT "parts_specificTypeId_fkey" FOREIGN KEY ("specificTypeId") REFERENCES "specifictypes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_specificTypeId_fkey" FOREIGN KEY ("specificTypeId") REFERENCES "specifictypes"("id") ON DELETE SET NULL ON UPDATE CASCADE;
