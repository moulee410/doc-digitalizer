/*
  Warnings:

  - Added the required column `label` to the `attributenames` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "attributenames" ADD COLUMN     "label" TEXT NOT NULL;
